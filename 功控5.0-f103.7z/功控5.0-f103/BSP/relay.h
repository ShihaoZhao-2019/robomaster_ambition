#ifndef __RELAY_H
#define __RELAY_H	 
#include "sys.h"

#define RELAY_POWER PAout(10)


void RELAY_Init(void);//��ʼ��

		 				    
#endif
