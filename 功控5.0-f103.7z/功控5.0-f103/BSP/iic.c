#include "main.h"

void SDA1_InPutMode(void)  {SDA1_IN();}
void SDA1_OutPutMode(void) {SDA1_OUT();}
void SDA1_OutPut(uint8_t val) {I2C1_SDA = val;}

//void SDA2_InPutMode(void)  {SDA2_IN();}
//void SDA2_OutPutMode(void) {SDA2_OUT();}
//void SDA2_OutPut(uint8_t val) {I2C2_SDA = val;}

//void SDA3_InPutMode(void)  {SDA3_IN();}
//void SDA3_OutPutMode(void) {SDA3_OUT();}
//void SDA3_OutPut(uint8_t val) {I2C3_SDA = val;}

//void SDA4_InPutMode(void)  {SDA4_IN();}
//void SDA4_OutPutMode(void) {SDA4_OUT();}
//void SDA4_OutPut(uint8_t val) {I2C4_SDA = val;}

void i2c_Init(I2CStruct *I2C)
{
	GPIO_InitTypeDef GPIO_InitStructure;
  I2C->GPIO_CLK(I2C->GPIO_Func, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = I2C->SCL_Pin|I2C->SDA_Pin;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(I2C->Gpio, &GPIO_InitStructure);
	I2C->i2cSet(I2C->Gpio,I2C->SDA_Pin);
	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
}
void I2C_Start(I2CStruct *I2C)
{
	I2C->sda_out();
	I2C->i2cSet(I2C->Gpio,I2C->SDA_Pin);
	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
	delay_us(4);
	I2C->i2cReset(I2C->Gpio,I2C->SDA_Pin);
	delay_us(4);
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
//	delay_us(2);
//	I2C->i2cSet(I2C->Gpio,I2C->SDA_Pin);
//	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
}
void I2C_Stop(I2CStruct *I2C )
{

  I2C->sda_out();    
	I2C->i2cReset(I2C->Gpio,I2C->SDA_Pin);
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
	delay_us(4);
	I2C->i2cSet(I2C->Gpio,I2C->SDA_Pin);
	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
	delay_us(4);
}

void I2C_Ack(I2CStruct *I2C)
{
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
  I2C->sda_out();    	
	I2C->i2cReset(I2C->Gpio,I2C->SDA_Pin);
	delay_us(2);
	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
	delay_us(2);
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
}
void I2C_NoAck(I2CStruct *I2C)
{
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
  I2C->sda_out(); 
	I2C->i2cSet(I2C->Gpio,I2C->SDA_Pin);
	delay_us(2);
	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
	delay_us(2);
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
}
u8 I2C_WaitACK(I2CStruct *I2C)
{
	u8 errtime = 0;
	I2C->sda_in();
	I2C->i2cSet(I2C->Gpio,I2C->SDA_Pin);
	delay_us(1);
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
	delay_us(1);		 
	while(I2C->i2cReadSda(I2C->Gpio,I2C->SDA_Pin))
	{
		errtime++;
		if(errtime>250)
		{
			I2C_Stop(I2C);
			return 1;
		}
	}
	I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
	delay_us(4);
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
	return 0;
}
void I2C_WRData(I2CStruct *I2C, u8 data)
{
	u8 i;
  I2C->sda_out(); 
	I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
	for(i=0;i<8;i++)
	{	
		I2C->sdaOutPut((data&0x80)>>7);
		data<<=1;
		delay_us(2);
	  I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
		delay_us(2);
		I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
		delay_us(2);
	}	
}

u8 I2C_RDData(I2CStruct *I2C, u8 ack)
{
	u8 i,data=0;
  I2C->sda_in();
	for(i=0;i<8;i++)
	{
		I2C->i2cReset(I2C->Gpio,I2C->SCL_Pin);
    delay_us(2);
		I2C->i2cSet(I2C->Gpio,I2C->SCL_Pin);
		data<<=1;
		if(I2C->i2cReadSda(I2C->Gpio,I2C->SDA_Pin)) data++;   
		delay_us(1); 
	}
	if(ack) I2C_Ack(I2C);
	else I2C_NoAck(I2C);		
	return data;
}
//void ExtI2C_Init(void)
//{
//	GPIO_InitTypeDef GPIO_InitStructure;
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
//	
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 |GPIO_Pin_7 |GPIO_Pin_8 |\
//	                              GPIO_Pin_9| GPIO_Pin_11| GPIO_Pin_13| GPIO_Pin_14;
//	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
//	
//	I2C1_SCL = 1;
//	I2C1_SDA = 1;
//	
//}

//void I2C_Start(void)
//{
//	SDA_OUT();     
//	I2C_SDA = 1;
//	I2C_SCL = 1;
//	delay_us(4);
//	I2C_SDA = 0;
//	delay_us(4);
//	I2C_SCL = 0;
//}

//void I2C_Stop(void)
//{
////	I2C_SDAOut();
//	SDA_OUT();     
//	I2C_SCL = 0;
//	I2C_SDA = 0;
//	delay_us(4);
//	I2C_SCL = 1;
//	I2C_SDA = 1;
//	delay_us(4);
//}

//void I2C_Ack(void)
//{
////	I2C_SDAOut();
//	I2C_SCL = 0;
//	SDA_OUT();     	
//	I2C_SDA = 0;
//	delay_us(2);
//	I2C_SCL = 1;
//	delay_us(2);
//	I2C_SCL = 0;
//}

//void I2C_NoAck(void)
//{
////	I2C_SDAOut();
//	I2C_SCL = 0;
//	SDA_OUT();
//	I2C_SDA = 1;
//	delay_us(2);
//	I2C_SCL = 1;
//	delay_us(2);
//	I2C_SCL = 0;
//}

//u8 I2C_WaitACK(void)
//{
//	u8 errtime = 0;
////	I2C_SDAIn(); 
//	SDA_IN();
//	I2C_SDA=1;
//	delay_us(1);
//	I2C_SCL=0;
//	delay_us(1);		 
//	while(I2C_RDSDA)
//	{
//		errtime++;
//		if(errtime>250)
//		{
//			delay_ms(65530);
//			I2C_Stop();
//			return 1;
//		}
//	}
//	I2C_SCL = 1;
//	delay_us(4);
//	I2C_SCL = 0;	
//	return 0;
//}

//void I2C_WRData(u8 data)
//{
//	u8 i;
//	SDA_OUT();
//	I2C_SCL = 0;
//	for(i=0;i<8;i++)
//	{	
//		I2C_SDA = (data&0x80)>>7;
//		data<<=1;
//		delay_us(2);
//		I2C_SCL = 1;
//		delay_us(2);
//		I2C_SCL = 0;
//		delay_us(2);
//	}	
//}

//u8 I2C_RDData(u8 ack)
//{
//	u8 i,data=0;
////	I2C_SDAIn();
//	SDA_IN();
//	for(i=0;i<8;i++)
//	{
//		I2C_SCL = 0;
//    delay_us(2);
//		I2C_SCL = 1;
//        data<<=1;
//        if(I2C_RDSDA) data++;   
//		delay_us(1); 
//	}
//	if(ack) I2C_Ack();
//	else I2C_NoAck();		
//	return data;
//}





