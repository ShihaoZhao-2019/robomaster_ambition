#ifndef __INA226_H
#define __INA226_H
#include "sys.h"


#define 	CFG_REG	 		0x00
#define 	SV_REG 			0x01
#define 	BV_REG 			0x02
#define 	PWR_REG 		0x03
#define 	CUR_REG 		0x04
#define 	CAL_REG 		0x05
#define 	ONFF_REG 		0x06
#define 	AL_REG 			0x07
#define   	INA226_ADDR1	0x90     //��Դ
#define   	INA226_ADDR2	0x88    //CAP
#define   	INA226_ADDR3	0x80     //���
#define   	INA226_GETALADDR	0x14 


extern float voltageVal[3];
extern float currentVal[3];
extern float powerVal[3];

void INA226_Init(void);
//void INA226_Init(I2CStruct *I2C);

void INA226_SetRegPointer(I2CStruct *I2C, u8 addr,u8 reg);
void INA226_SendData(I2CStruct *I2C, u8 addr,u8 reg,u16 data);

u16 INA226_GetShunt_Current(I2CStruct *I2C, u8 addr);
u16 INA226_ReadData(I2CStruct *I2C, u8 addr);
u8	INA226_AlertAddr(I2CStruct *I2C);
u16 INA226_GetVoltage(I2CStruct *I2C, u8 addr);
u16 INA226_GetCurrent(I2CStruct *I2C, u8 addr);
u16 INA226_GetShuntVoltage(I2CStruct *I2C, u8 addr);
void GetVoltage(float *Voltage);
void GetCurrent(float *Current);
void GetPower(float *Power ,float *Current, float *Voltage);//W
u16 INA226_GET_CAL_REG(I2CStruct *I2C, u8 addr);
u16 INA226_Get_Power(I2CStruct *I2C, u8 addr);
float fifo_moving(float data, float FIFO[]);

#endif
