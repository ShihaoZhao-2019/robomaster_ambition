#ifndef _IIC_H
#define _IIC_H
#include "sys.h"

#define I2C1_SCL_Pin GPIO_Pin_6
#define I2C1_SDA_Pin GPIO_Pin_7
#define I2C1_SCL PBout(6)
#define I2C1_SDA PBout(7)
#define I2C1_RDSDA PBin(7)
//#define SDA1_IN()
//#define SDA1_OUT()
#define SDA1_IN()  {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRL|=(u32)8<<28;}
#define SDA1_OUT() {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRL|=(u32)3<<28;}

//#define I2C2_SCL_Pin GPIO_Pin_10
//#define I2C2_SDA_Pin GPIO_Pin_11
//#define I2C2_SCL PBout(10)
//#define I2C2_SDA PBout(11)
//#define I2C2_RDSDA PBin(11)
//#define SDA2_IN()  {GPIOB->CRH&=0XFFFF0FFF;GPIOB->CRH|=(u32)8<<12;}
//#define SDA2_OUT() {GPIOB->CRH&=0XFFFF0FFF;GPIOB->CRH|=(u32)3<<12;}

//#define I2C3_SCL_Pin GPIO_Pin_8
//#define I2C3_SDA_Pin GPIO_Pin_9
//#define I2C3_SCL PBout(8)
//#define I2C3_SDA PBout(9)
//#define I2C3_RDSDA PBin(9)
//#define SDA3_IN()  {GPIOB->CRH&=0XFFFFFF0F;GPIOB->CRH|=(u32)8<<4;}
//#define SDA3_OUT() {GPIOB->CRH&=0XFFFFFF0F;GPIOB->CRH|=(u32)3<<4;}

//#define I2C4_SCL_Pin GPIO_Pin_13
//#define I2C4_SDA_Pin GPIO_Pin_14
//#define I2C4_SCL PBout(13)
//#define I2C4_SDA PBout(14)
//#define I2C4_RDSDA PBin(14)
//#define SDA4_IN()  {GPIOB->CRH&=0XF0FFFF0F;GPIOB->CRH|=(u32)8<<24;}
//#define SDA4_OUT() {GPIOB->CRH&=0XF0FFFF0F;GPIOB->CRH|=(u32)3<<24;}

typedef void (*VOID)(void);
typedef void (*RCC_AXXPeriphClockCmd)(uint32_t RCC_APB2Periph, FunctionalState NewState);
typedef void (*set)(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
typedef uint8_t (*read)(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
typedef void (*out)(uint8_t val);
typedef struct 
{
	GPIO_TypeDef* Gpio;
	RCC_AXXPeriphClockCmd GPIO_CLK;
	uint32_t GPIO_Func;
	
  set i2cSet;
	set i2cReset;
	read i2cReadSda;
	
	uint16_t SCL_Pin;
	uint16_t SDA_Pin;
	
  VOID sda_in;
  VOID sda_out;	

	out sdaOutPut;
	uint32_t AAA;
	
}I2CStruct;

void SDA1_InPutMode(void);
void SDA1_OutPutMode(void);
void SDA1_OutPut(uint8_t val);

//void SDA2_InPutMode(void);
//void SDA2_OutPutMode(void);
//void SDA2_OutPut(uint8_t val);

//void SDA3_InPutMode(void);
//void SDA3_OutPutMode(void);
//void SDA3_OutPut(uint8_t val);

//void SDA4_InPutMode(void);
//void SDA4_OutPutMode(void);
//void SDA4_OutPut(uint8_t val);


void i2c_Init(I2CStruct *I2C);
void I2C_Start(I2CStruct *I2C);
void I2C_Stop(I2CStruct *I2C);
void I2C_SDAIn(I2CStruct *I2C);
void I2C_SDAOut(I2CStruct *I2C);
void I2C_Ack(I2CStruct *I2C);
void I2C_NoAck(I2CStruct *I2C);
u8 I2C_WaitACK(I2CStruct *I2C);
void I2C_WRData(I2CStruct *I2C, u8 data);
u8 I2C_RDData(I2CStruct *I2C, u8 ack);

//void ExtI2C_Init(void);
//void I2C_Start(void);
//void I2C_Stop(void);
//void I2C_SDAIn(void);
//void I2C_SDAOut(void);
//void I2C_Ack(void);
//void I2C_NoAck(void);
//void I2C_WRData(u8 data);
//u8 I2C_WaitACK(void);
//u8 I2C_RDData(u8 ack);

#endif
