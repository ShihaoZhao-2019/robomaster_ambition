#include "main.h"



float voltageVal[3];	//��ѹ//0 ��Դ//1 ����//2 ���
float currentVal[3];	//����//0 ��Դ//1 ����//2 ���
float powerVal[3];		//����//0 ��Դ//1 ����//2 ���


/////////////
//2��ŷ����//   
////////////

/////////////
//1��ŷ����//
////////////

//Configuration Register 00h  ===  0x43FF === D15-RST;D12:D14-000 ; D9:D11(AVG)-001 ; D6:D8(VBCT)-111 ; D3:D5(VSHCT)-111 ; D0-D2(MODE)-111
//Shunt Voltage Register 01h (Read-Only)2.5uV/bit  ===  D15:������־ ; D0:D14-DATA ; ����:�����Ʋ��� +1
//Bus Voltage Register 02h (Read-Only)1.25mV/bit  ===  d15:0 ; D0:D14 - DATA ; ��֧�ָ���ѹ���
//Power Register 03h (Read-Only) --- 25*Current_LSB/bit === D0:D15 - DATA
//Current Register 04h (Read-Only)1mA/bit === d15:0 ; D0:D14 - DATA 
//Calibration Register 05h (Read/Write) === 0xA00 === d15:0 ; D0:D14 - DATA 
//Mask/Enable 06h (Read/Write) === 0x0000H ===
//Bit 15 - SOL: Shunt Voltage Over-Voltage  
//Bit 14 - SUL: Shunt Voltage Under-Voltage 
//Bit 13 - BOL: Bus Voltage Over-Voltage 
//Bit 12 - BUL: Bus Voltage Under-Voltage 
//Bit 11 - POL: Over-Limit Power
//Bit 10 - CNVR: Conversion Read 
//Bit 4 - AFF: Alert Function Flag 
//Bit 3 - CVRF: Conversion Ready Flag 
//Bit 2 - OVF: Math Overflow Flag 
//Bit 1 - APOL: Alert Polarity bit; sets the Alert pin polarity.
//Bit 0 - LEN: Alert Latch Enable; configures the latching feature of the Alert pin and Flag bits.
//Alert Limit 07h (Read/Write) === 0x0000H === D0:D15 - DATA 
//INA226 ADDR : 1000000 


/////////////
//50��ŷ����//
////////////
static I2CStruct mMI2C_1 = {
	GPIOB,
	RCC_APB2PeriphClockCmd,
	RCC_APB2Periph_GPIOB,
	
	GPIO_SetBits,
	GPIO_ResetBits,
	GPIO_ReadInputDataBit,
	
	I2C1_SCL_Pin,
	I2C1_SDA_Pin,
	
	SDA1_InPutMode,
  SDA1_OutPutMode,	
	
	SDA1_OutPut

};
static I2CStruct* pMI2C_1 = &mMI2C_1;

//static I2CStruct mMI2C_2 = {
//	GPIOB,
//	RCC_APB2PeriphClockCmd,
//	RCC_APB2Periph_GPIOB,
//	
//	GPIO_SetBits,
//	GPIO_ResetBits,
//	GPIO_ReadInputDataBit,
//	
//	I2C2_SCL_Pin,
//	I2C2_SDA_Pin,
//	
//	SDA2_InPutMode,
//  SDA2_OutPutMode,	
//	
//	SDA2_OutPut
//};
//static I2CStruct* pMI2C_2 = &mMI2C_2;

//static I2CStruct mMI2C_3 = {
//	GPIOB,
//	RCC_APB2PeriphClockCmd,
//	RCC_APB2Periph_GPIOB,
//	
//	GPIO_SetBits,
//	GPIO_ResetBits,
//	GPIO_ReadInputDataBit,
//	
//	I2C3_SCL_Pin,
//	I2C3_SDA_Pin,
//	
//	SDA3_InPutMode,
//  SDA3_OutPutMode,	
//	
//	SDA3_OutPut

//};
//static I2CStruct* pMI2C_3 = &mMI2C_3;

//static I2CStruct mMI2C_4 = {
//	GPIOB,
//	RCC_APB2PeriphClockCmd,
//	RCC_APB2Periph_GPIOB,
//	
//	GPIO_SetBits,
//	GPIO_ResetBits,
//	GPIO_ReadInputDataBit,
//	
//	I2C4_SCL_Pin,
//	I2C4_SDA_Pin,
//	
//	SDA4_InPutMode,
//  SDA4_OutPutMode,	
//	
//	SDA4_OutPut
//};
//static I2CStruct* pMI2C_4 = &mMI2C_4;

void INA226_Init(void)
{	
	i2c_Init(pMI2C_1);

	delay_ms(10);
	INA226_SendData(pMI2C_1,INA226_ADDR1,CFG_REG,0x484f);// ��Դ
	INA226_SendData(pMI2C_1,INA226_ADDR1,CAL_REG,0x1400);
	delay_ms(10);
	INA226_SendData(pMI2C_1,INA226_ADDR2,CFG_REG,0x484f);// CAP
	INA226_SendData(pMI2C_1,INA226_ADDR2,CAL_REG,0x1400);
	delay_ms(10);
	INA226_SendData(pMI2C_1,INA226_ADDR3,CFG_REG,0x484f);//���
	INA226_SendData(pMI2C_1,INA226_ADDR3,CAL_REG,0x1400);
	
}


void INA226_SetRegPointer(I2CStruct *I2C,u8 addr,u8 reg)
{
	I2C_Start(I2C);

	I2C_WRData(I2C, addr);
	I2C_WaitACK(I2C);

	I2C_WRData(I2C, reg);
	I2C_WaitACK(I2C);

	I2C_Stop(I2C);
}

void INA226_SendData(I2CStruct *I2C, u8 addr,u8 reg,u16 data)
{
	u8 temp=0;
	I2C_Start(I2C);

	I2C_WRData(I2C, addr);
	I2C_WaitACK(I2C);
	
	I2C_WRData(I2C, reg);
	I2C_WaitACK(I2C);
	
	temp = (u8)(data>>8);
	I2C_WRData(I2C, temp);
	I2C_WaitACK(I2C);
 
	temp = (u8)(data&0x00FF);
	I2C_WRData(I2C, temp);
	I2C_WaitACK(I2C);
	
	I2C_Stop(I2C);
}

u16 INA226_ReadData(I2CStruct *I2C, u8 addr)
{
	u16 temp=0;
	I2C_Start(I2C);

	I2C_WRData(I2C, addr+1);
	I2C_WaitACK(I2C);
	
	temp = I2C_RDData(I2C, 1);
	temp<<=8;	
	temp |= I2C_RDData(I2C, 0);
	
	I2C_Stop(I2C);
	return temp;
}

//u16 INA226_GET_CAL_REG(I2CStruct *I2C,u8 addr)
//{	
//	u32 temp=0;
//	
//	INA226_SetRegPointer(I2C,addr,CAL_REG);
//	temp = INA226_ReadData(I2C,addr);
//	return (u16)temp;
//}
//u16 INA226_Get_Power(I2CStruct *I2C,u8 addr)
//{
//	int16_t temp=0;
//	INA226_SetRegPointer(I2C,addr,PWR_REG);
//	temp = INA226_ReadData(I2C,addr);
//	return (u16)temp;
//}

//u8 INA226_AlertAddr(I2CStruct *I2C)
//{
//	u8 temp;
//	I2C_Start(I2C);

//	I2C_WRData(I2C, INA226_GETALADDR);
//	I2C_WaitACK(I2C);
//	
//	temp = I2C_RDData(I2C, 1);
//	
//	I2C_Stop(I2C);
//	return temp;
//}

//1mA/bit
//u16 INA226_GetCurrent(I2CStruct *I2C, u8 addr)
//{
//	u16 temp=0;	
//	INA226_SetRegPointer(I2C, addr,SV_REG);
//	temp = INA226_ReadData(I2C,addr);
//	if(temp&0x8000)
//	{
//		temp = ~(temp - 1);	
////		temp = (temp*25 + 5) / 10 / 5;
//	}
//	else
//	{
//		INA226_SetRegPointer(I2C,addr, CUR_REG);
//		temp = INA226_ReadData(I2C, addr);
//		temp = temp&0x7fff;
//	}
////	printf("g%d\r\n",temp);
//	return temp;
//}
u16 INA226_GetShunt_Current(I2CStruct *I2C, u8 addr)
{
	u16 temp=0;	
	INA226_SetRegPointer(I2C,addr,CUR_REG);
	temp = INA226_ReadData(I2C,addr);
	if(temp&0x8000)	temp = ~(temp - 1);	
	
	return temp;
}


//1.25mV/bit
u16 INA226_GetVoltage(I2CStruct *I2C, u8 addr)
{
	u32 temp=0;
	INA226_SetRegPointer(I2C, addr,BV_REG);
	temp = INA226_ReadData(I2C,addr);

	return (u16)temp;	
}

//2.5uV/bit
u16 INA226_GetShuntVoltage(I2CStruct *I2C, u8 addr)
{
	int16_t temp=0;
	INA226_SetRegPointer(I2C, addr,SV_REG);
	temp = INA226_ReadData(I2C, addr);
	if(temp&0x8000)	temp = ~(temp - 1);	

	return (u16)temp;	
}

#define DATA_number	5
float FIFO_1[DATA_number];
float FIFO_2[DATA_number];
float FIFO_3[DATA_number];

void GetVoltage(float *Voltage)//mV
{
	Voltage[0] = INA226_GetVoltage(pMI2C_1, INA226_ADDR1)*0.00125f;
//	Voltage[0] = fifo_moving(Voltage[0], FIFO_1);
	
	Voltage[1] = INA226_GetVoltage(pMI2C_1, INA226_ADDR2)*0.00125f;
	Voltage[1] = fifo_moving(Voltage[1], FIFO_2);
	
//	Voltage[2] = INA226_GetVoltage(pMI2C_1, INA226_ADDR3)*0.00125f;
	
//	Voltage[3] = INA226_GetVoltage(pMI2C_4, INA226_ADDR1)*1.25f;
}
void GetCurrent(float *Current)//mA
{
	Current[0] = (INA226_GetShunt_Current(pMI2C_1, INA226_ADDR1) *0.0042f);
	
	Current[1] = (INA226_GetShunt_Current(pMI2C_1, INA226_ADDR2) *0.0042f);
	
//	Current[2] = (INA226_GetShunt_Current(pMI2C_1, INA226_ADDR3) *0.0042f);
	
//	Current[3] = (INA226_GetShuntVoltage(pMI2C_4, INA226_ADDR1)* 1.25f);
}
void GetPower(float *Power ,float *Current, float *Voltage)//W
{
	Power[0] = 1.3f * (Current[0] * Voltage[0] + P_INIT);
	
	Power[1] = Current[1] * Voltage[1];
	
//	Power[2] = Current[2] * Voltage[2];
	
//	Power[3] = Current[3]*0.001f * Voltage[3]*0.001f;
}

float fifo_moving(float data, float FIFO[])
{
	float data_sum = 0;
	FIFO[0] = data;
	for(int i = 0; i < (DATA_number - 1); i++)
	{
		FIFO[i + 1] = FIFO[i];
	}
	for(int j = 0; j < DATA_number; j++)
	{
		data_sum += FIFO[j]; 
	}
	
	return data_sum / DATA_number;

}








