#include "main.h"

float voltageVal[3];	//��ѹ//0 ��Դ//1 ����//2 ���
float currentVal[3];	//����//0 ��Դ//1 ����//2 ���
float powerVal[3];		//����//0 ��Դ//1 ����//2 ���


void GetVoltage(float *Voltage)//mV
{
	Voltage[0] = INA226_GetVoltage(pMI2C_1, INA226_ADDR1)*0.00125f;
	
	Voltage[1] = INA226_GetVoltage(pMI2C_1, INA226_ADDR2)*0.00125f;
	
	Voltage[2] = INA226_GetVoltage(pMI2C_1, INA226_ADDR3)*0.00125f;
	
//	Voltage[3] = INA226_GetVoltage(pMI2C_4, INA226_ADDR1)*1.25f;
}
void GetCurrent(float *Current)//mA
{
	Current[0] = (INA226_GetShunt_Current(pMI2C_1, INA226_ADDR1) *0.0042f);
	
	Current[1] = (INA226_GetShunt_Current(pMI2C_1, INA226_ADDR2) *0.0042f);
	
	Current[2] = (INA226_GetShunt_Current(pMI2C_1, INA226_ADDR3) *0.0042f);
	
//	Current[3] = (INA226_GetShuntVoltage(pMI2C_4, INA226_ADDR1)* 1.25f);
}
void GetPower(float *Power ,float *Current, float *Voltage)//W
{
	Power[0] = Current[0] * Voltage[0];
//	Power[1] = Current[1] * Voltage[1];
	Power[2] = Current[2] * Voltage[2];
//	Power[3] = Current[3]*0.001f * Voltage[3]*0.001f;
}



