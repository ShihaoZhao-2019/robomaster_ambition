#ifndef		_PID_H_
#define		_PID_H_

#include "delay.h"
//�궨��pid�ṹ�������±�

#define LET_IN_P 		0
#define ALL_PID 		1


typedef struct PID
{
	float kp;
	float ki;
	float kd;
	
	float pout;
	float iout;
	float dout;
	
	float poutmax;
	float ioutmax;
	float doutmax;
	float outmax;
	
	float set;
	float real;
	float out;
	
	float err;							//����ƫ��ֵ
	float err_last;					//��һ��ƫ��ֵ
	float err_llast;				//���ϴ�ƫ��ֵ
	float integral;					//�ۼ�ƫ��ֵ
	void(*f_pid_init)(struct PID *pid, float kp, float ki, float kd, float poutmax, float ioutmax, float doutmax, float outmax);			//������ʼ��pid
	void(*f_pid_reset)(struct PID *pid);
}PID;

extern PID pid[ALL_PID];
extern float pid_out[ALL_PID];
static void pid_init(PID *pid, float kp, float ki, float kd, float poutmax, float ioutmax, float doutmax, float outmax);
static void pid_reset(PID *pid);

void All_Pid_Configuration(PID pid[]);
float Calculate_Current_Value(PID *pid, float set, float real);

#endif
