#ifndef _CHANGE_H_
#define _CHANGE_H_

#include "sys.h"

#define IN_R_MAX		6.0f	//50W
#define IN_R_MIN		2.0f	//����ܳ�����

#define	IN_POWER_KEEP	55.0f
#define MOTOR_V_MIN		17.0f	//�����͵�ѹ
#define V_CHANGE		15.0f



typedef struct
{
	float set;
	float real;
	float out;
	int16_t time;
}Power_Data;

extern Power_Data power_data;
extern uint8_t change1_flag;//0����
extern uint8_t change2_flag;
extern uint8_t change3_flag;

void Change_control(void);
void free_time(void);
void let_out(void);
void let_in(void);
void power_out_up(void);
void state_record(uint8_t state, int16_t out);
void R_out(int16_t out);
#endif




