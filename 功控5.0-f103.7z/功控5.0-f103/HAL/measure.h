#ifndef _MEASURE_H_
#define _MEASURE_H_

extern float voltageVal[3];
extern float currentVal[3];
extern float powerVal[3];

void GetVoltage(float *Voltage);
void GetCurrent(float *Current);
void GetPower(float *Power ,float *Current, float *Voltage);//W


#endif