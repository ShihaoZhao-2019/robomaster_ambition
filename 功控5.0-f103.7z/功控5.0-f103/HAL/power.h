#ifndef __POWER_H
#define __POWER_H	 

#include "sys.h"	

void power_count(void);


#define P_INIT	5.0f
#define P_MAX	80.0f
#define W_MAX	60.0f
#define W_MIN	0.0f

typedef struct
{
	uint8_t less_flag;
	float last_power;
	float now_power;
	
	
}Power_W;

extern Power_W power_w;

#endif

