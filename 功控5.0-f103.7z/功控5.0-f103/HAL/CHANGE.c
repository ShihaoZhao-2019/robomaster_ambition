#include "main.h"

uint8_t change1_flag = 0;//0����
uint8_t change2_flag = 0;
uint8_t change3_flag = 0;
uint8_t U_flag = 2;

Power_Data power_data ={0};

int16_t last_and_out = 0,now_and_out = 0,now_out = 0;

void Change_control()
{
	//״̬�ж�
	if(real_voltageVal < MOTOR_V_MIN)
	{
		can_data.can_tx_1 = 1;
		U_flag = 1;
		
		if(can_data.can_rx_1 == 1)//��Դ�ŵ�//���ݲ����
		{
			free_time();
		}
		else if(can_data.can_rx_1 == 3)//���ݳ��//��Դ�ŵ�
		{
			let_in();//����������
		}
	}
	else if((real_voltageVal < (MOTOR_V_MIN + 1.0f)) && (real_voltageVal >= MOTOR_V_MIN))
	{	
		if(can_data.can_rx_1 == 1)//��Դ�ŵ�//���ݲ����
		{
			free_time();
		}
		else if(can_data.can_rx_1 == 2)//���ݷŵ�//��Դ���ŵ�
		{
			let_out();
		}
		else if(can_data.can_rx_1 == 3)//���ݳ��//��Դ�ŵ�
		{
			let_in();//����������
		}
	}
	else if(real_voltageVal >= (MOTOR_V_MIN + 1.0f)) //���ݸ���
	{
		if(real_voltageVal >= (MOTOR_V_MIN + 2.0f))
		{
			U_flag = 2;
		}
		
		if(U_flag == 2)
		{
			can_data.can_tx_1 = 2;
		}
		
		if(can_data.can_rx_1 == 1)//��Դ�ŵ�//���ݲ����
		{
			free_time();
		}
		else if(can_data.can_rx_1 == 2)//���ݷŵ�//��Դ���ŵ�
		{
			let_out();
		}
		else if(can_data.can_rx_1 == 3)//���ݳ��//��Դ�ŵ�
		{
			let_in();//����������
		}
	}

}

void free_time()
{
	change2_flag = 0;
	change3_flag = 0;
	
	if(change1_flag == 0)//��һ�ν�״̬ ����
	{
		RELAY_POWER = 0;				//�ص���
		change1_flag = 1;
		R_out(0);
		MOS_PowerSupply();//MOS����
	}
	else
	{
		MOS_PowerSupply();//MOS����
	}
}

void let_out()
{
	change1_flag = 0;
	change3_flag = 0;	
	
	if(change2_flag == 0)
	{
		RELAY_POWER = 0;				//�ص���
		change2_flag = 1;
		R_out(0);
		MOS_SuperCap();
	}
	else
	{
		MOS_SuperCap();
	}
}

void let_in()
{
	
	change1_flag = 0;
	change2_flag = 0;
	
	if(change3_flag == 0)
	{
		RELAY_POWER = 1;				//������
		change3_flag = 1;
		R_out(0);
		MOS_PowerSupply();
		R_out(2);
	}
	else
	{
		MOS_PowerSupply();	
		power_out_up();

	}
}

void power_out_up()
{
	power_data.set = IN_POWER_KEEP;
	power_data.real = powerVal[1];
	
	if(real_voltageVal < V_CHANGE)
	{
		pid_out[LET_IN_P] = Calculate_Current_Value(&pid[LET_IN_P], power_data.set, power_data.real);
		power_data.out = pid_out[LET_IN_P];
		
		power_data.out = power_data.out > IN_R_MAX ? IN_R_MAX : power_data.out;
		power_data.out = power_data.out < IN_R_MIN ? IN_R_MIN : power_data.out;
		
		R_out(power_data.out);
	}
	else if((real_voltageVal >=  V_CHANGE) && (real_voltageVal <= (voltageVal[0] - 1.0f)))
	{
		power_data.time ++;

		if(power_data.time <= 3)
		{
			R_out(0);
		}
		else
		{
			R_out(IN_R_MIN);		
		}
		
		if(power_data.time >= 4)//20ms
		{
			power_data.time = 0;
		}
	}
	else if(real_voltageVal > (voltageVal[0] - 1.0f))
	{
		R_out(IN_R_MIN);
	}
}


void state_record(uint8_t state, int16_t out)//��¼���ֵ�λ���
{
	last_and_out = now_and_out ;
	now_out = out;
	if(state == 0)//��С
	{
		now_and_out = last_and_out - now_out;
	}
	else if(state == 1)
	{
		now_and_out = last_and_out + now_out;
	}
}

void R_out(int16_t out)//0`100	Rֵ
{
	if(now_and_out < out)
	{
		RES_ContinuousDecrease(out - now_and_out);
		state_record(1, out - now_and_out);
	}
	else if(now_and_out > out)
	{
		RES_ContinuousIncrease(now_and_out - out);
		state_record(0, now_and_out - out);
	}
	else{}//�޲���
}

