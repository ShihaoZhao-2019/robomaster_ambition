#include "main.h"

Power_W power_w = {0, W_MAX, W_MAX};

void power_count()
{
	power_w.now_power = power_w.last_power - (powerVal[0] - P_MAX) * 0.005;
	
	if(power_w.now_power <= W_MIN)
	{
		power_w.now_power = W_MIN;
	}
	else if(power_w.now_power >= W_MAX)
	{
		power_w.now_power = W_MAX;
	}
	
	power_w.last_power = power_w.now_power ;
	
	
	can_data.can_tx_2 = power_w.now_power;
}

