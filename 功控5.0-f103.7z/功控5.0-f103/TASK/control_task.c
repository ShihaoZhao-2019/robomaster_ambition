#include "main.h"

//int times;

//int qaz,wsx;

float now_voltageVal,diff_voltageVal,real_voltageVal;
int16_t times;
float W_AND;

void control_task()
{
	
//	LED_IndicatorLight();	//LED
	
	power_count();
	
	times++;
	if(times >= 20)
	{
		times = 0;
		

		
		if(real_voltageVal != 0)
		{
			now_voltageVal = voltageVal[1];
			diff_voltageVal = fabs(now_voltageVal - real_voltageVal);
			if(diff_voltageVal < 1.0f)
			{
				real_voltageVal = now_voltageVal;
			}
		}
		else
		{
			now_voltageVal = voltageVal[1];
			real_voltageVal = now_voltageVal;
		}
	}
	
	Change_control();
	
//	W_AND += powerVal[0] * 0.005f;
//	can_data.can_tx_2 = W_AND;
	
	
	
//	qaz++;
//	if(qaz > 200)
//	{
//		qaz = 0;
//		wsx++;
//	}
	

//	times++;
//	if(times <= 2000)
//		can_data.can_tx = 1;
//	else
//		can_data.can_tx = 2;
//	
//	if(times >= 4000)
//		times = 0;
	
	

//	times++;
//	if(times <= 20)
//	{
//		free_time();
//	}
//	else
//		let_out();
//	
//	if(times >= 40)
//	{
//		times = 0;
//	}
	
	
//	let_in();
//	let_out();


	Set_Flag_Current(can_data.can_tx_1, can_data.can_tx_2);//״̬��//1	���ڰ�ȫ��ѹ//2	���밲ȫ��ѹ
}



void control_task_Init()
{
	MOS_PowerSupply();				//��Դ�ŵ�
	RES_ContinuousIncrease(100);	//�������ݳ��
}


