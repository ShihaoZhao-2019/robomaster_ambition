#ifndef _CONTROL_TASK_H_
#define _CONTROL_TASK_H_

void control_task(void);
void control_task_Init(void);

extern float last_voltageVal,now_voltageVal,diff_voltageVal,real_voltageVal;

#endif
