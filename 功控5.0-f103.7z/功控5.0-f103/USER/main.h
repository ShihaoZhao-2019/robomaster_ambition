#ifndef __MAIN_H
#define __MAIN_H	 

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "math.h"

#include "bsp.h"
#include "timer.h"
#include "led.h"
#include "iic.h"
#include "X9C103.h"
#include "ina226.h"
#include "can1.h"
#include "relay.h"
#include "power.h"

#include "MOS_control.h"
#include "CHANGE.h"
#include "pid.h"

#include "control_task.h" 				    

#endif

