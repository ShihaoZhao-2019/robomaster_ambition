#include </home/ambitiom/AmbitionVision/v1_1/include/ArmorFind.hpp>



int main()
{

    ArmorFind ambition_vision;

    namedWindow("���Բ���");
    createTrackbar("gbThreshValue:", "���Բ���", &ambition_vision.rgThresh,255);
    createTrackbar("kerThreshThreshValue:", "���Բ���", &ambition_vision.kerThresh, 100);
    ambition_vision.FindStart();
    return 0;



}
