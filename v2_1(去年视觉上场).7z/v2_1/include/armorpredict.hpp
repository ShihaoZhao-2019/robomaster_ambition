#ifndef __ARMOR_PREDICT
#define __ARMOR_PREDICT

#include "/home/ambitiom/AmbitionVision/v1_1/include/public_header.h"
#include <iostream>

using namespace std;

class ArmorPredict
{
public:

    ArmorPredict();
    void PredictMono(vector<Monodata> &mono_input,int videotype, double time, int robotlevel);

	

public:
		VisionData Data;
        //Rect armorRect;
		bool ifRoiFlag;
private :
	double T_curr, T_last;
	double T_between;
	AbsPosition mono_Pos;
    // 巴特沃斯滤波相关参数
    /*
    float b[3];
    float a[3];
    float usart_xBuf[3];
    float usart_yBuf[3];
    float usart_IIRLowPass(float x);
    */

    /////
	float mono_small_armor_720p_const;
	float mono_small_armor_1080p_const;
	float mono_big_armor_720p_const;
	float mono_big_armor_1080p_const;
	float mono_f_720p;
	float mono_f_1080p;
	float mono_base_720p;
	float mono_base_1080p;
	float mono_x;
	float mono_y;
	float mono_z;

};









#endif // !__ARMOR_PREDICT
