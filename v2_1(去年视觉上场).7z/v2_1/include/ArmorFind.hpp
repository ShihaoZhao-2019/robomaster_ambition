#ifndef __FIND
#define	__FIND

#include <iostream>
#include <opencv2/opencv.hpp>
#include "/home/ambitiom/AmbitionVision/v1_1/include/public_header.h"



using namespace std;
using namespace cv;





class ArmorFind
{
public:
	ArmorFind();
	void process(vector<vector<Point> > contours, const Mat &input, Mat &output, vector<Point> &result, bool ismono);
	void FindStart();
private:
	void Clear(void);
	void GetArmorLights(void);
	void GetArmors(Mat &image, bool ismono);
	void DrawCross(Mat &img, Point center, int size, Scalar color, int thickness = 2);
	void drawHeart(Mat &dstImage, Point center);
	void LightContour(int mode, Mat input, Mat &binary, int thres, vector<vector<Point> > &contours);
	double GetK(Point2f L1, Point2f L2);

public:
	Mat binary;
	Mat contourThreadkernel;
	vector<Point> ArmorCenters, ArmorOldCenters;
	vector<Monodata> monodata;
	
	VideoCapture cap;
	vector<Point> ArmorResult;
	vector<vector<Point>> contours;
	Mat image, result,bbinary;

	int rgThresh;
	int kerThresh;

private:
	int ArmorLostDelay;
	int armormin;
	Mat kernel;
	vector<vector<RotatedRect> > Armorlists;
	vector<int> CellMaxs;
	vector<Mat> splited;
	vector<vector<Point> > final;
	vector<Rect> Target;
	vector<Point> centers;
	vector<std::pair<Point, Rect> > PairContour;
	vector<RotatedRect> RectfirstResult, RectResults;//* save the lightbar
	Mat armor_roi;

};



#endif // __FIND
