#ifndef PUBLIC_HEADER_H
#define PUBLIC_HEADER_H

#include<opencv2/opencv.hpp>
#include<iostream>

using namespace std;
using namespace cv;


static inline bool RotateRectSort(RotatedRect a1, RotatedRect a2) {
    return a1.center.x < a2.center.x;
}


typedef struct {
    float x;
    float y;
    float z;
    int index;
}AbsPosition;


typedef union {
    int16_t d;
    unsigned char c[2];
}int16uchar;

typedef union {
    float f;
    unsigned char c[4];
}float2uchar;

typedef struct {
    typedef enum {
        small_armor,
        big_armor
    }armor_type;
    cv::Point center;
    float area;
    float distance;
    armor_type armor;
}Monodata;

typedef struct {
    unsigned char mode; // 1 auto 2 sudoku
    int16uchar yaw_angle;
    int16uchar pitch_angle;
    int16uchar yaw_speed;
    float2uchar shoot_speed;
    uint8_t    which;
    uint8_t    pos;

    float2uchar x;
    float2uchar y;
    float2uchar z;
}VisionData;


typedef struct {
    int mode; // 0 auto_attack_red 1 auto_attack_blue 50 sudoku 51 sudokunew 52 bulletadd
    int level;//0 1 2 3
}CarData;


#endif // PUBLIC_HEADER_H
