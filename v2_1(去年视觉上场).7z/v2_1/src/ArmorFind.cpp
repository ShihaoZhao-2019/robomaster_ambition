#include </home/ambitiom/AmbitionVision/v1_1/include/ArmorFind.hpp>
#include </home/ambitiom/AmbitionVision/v1_1/include/armorpredict.hpp>
#include </home/ambitiom/AmbitionVision/v1_1/include/serial.h>

#define BEATRED 0
#define BEATBLUE 1


ArmorFind::ArmorFind()
{
    ArmorLostDelay = 0;
    armormin = 10;
    rgThresh = 100;
    kerThresh = 9;
    contourThreadkernel = getStructuringElement(MORPH_ELLIPSE, Size(kerThresh, kerThresh));
}


void ArmorFind::LightContour(int mode, Mat input, Mat &binary, int thres, vector<vector<Point> > &contours) {
    Mat thres_whole;//,inputafter;
    vector<Mat> splited;
    //input.convertTo(inputafter,input.type(),1.5,-200);
    split(input, splited);
    cvtColor(input, thres_whole, CV_BGR2GRAY);
    contourThreadkernel = getStructuringElement(MORPH_ELLIPSE, Size(kerThresh, kerThresh));

    threshold(thres_whole, thres_whole, 50, 255, THRESH_BINARY);
    if (mode == 0) {
        subtract(splited[2], splited[0], binary);
        threshold(binary, binary, thres, 255, THRESH_BINARY);// red
    }
    else {
        subtract(splited[0], splited[2], binary);
        threshold(binary, binary, thres, 255, THRESH_BINARY);// blue
    }
    dilate(binary, binary, contourThreadkernel);
    binary = binary & thres_whole;
    findContours(binary, contours, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE);
}


/**
  * @brief find the armor center base on the position of the lightbar
  * @param contours: the contours of the lightbar
  * @param input   : the initial image by the camera
  * @param output  : the final output image includes the armor center
  * @param result  : position of armor centers in the image
  * @param ismono  : input 0 for binocular vision process, other for monocular process
  * @return none
  */
void ArmorFind::process(vector<vector<Point> > contours, const Mat &input, Mat &output, vector<Point> &result, bool ismono) {
    Clear();
    output = input.clone();
    RotatedRect RRect;
    // first judgement lightbar contours
    for (int i = 0; i < contours.size(); i++) {
        RRect = minAreaRect(contours[i]);
        if ((fabs(RRect.angle) < 45.0 && RRect.size.height > RRect.size.width)
            || (fabs(RRect.angle) > 45.0 && RRect.size.width > RRect.size.height)
            ) {
            RectfirstResult.push_back(RRect);
        }
    }
    if (RectfirstResult.size() < 2)
    {
        ArmorCenters.clear();
        return;
    }
    sort(RectfirstResult.begin(), RectfirstResult.end(), RotateRectSort);
    GetArmorLights();
    sort(RectResults.begin(), RectResults.end(), RotateRectSort);
    for (int i = 0; i < RectResults.size(); i++) {
        //std::cout<<"("<<RectResults[i].center.x<<","<<RectResults[i].center.y<<")"<<std::endl;
        ellipse(output, RectResults[i], Scalar(255, 0, 0), 2);
        /*ostringstream ss;
        ss<<i;
        putText(output,ss.str(),Point(RectResults[i].center.x,RectResults[i].center.y-5),FONT_HERSHEY_COMPLEX_SMALL, 1, Scalar(0,255,255));
        */
    }

    GetArmors(output, ismono);
    for (int i = 0; i < ArmorCenters.size(); i++) {
        DrawCross(output, ArmorCenters[i], 5, Scalar(0,0,255), 2);
        //drawHeart(output, ArmorCenters[i]);
    }
    result = ArmorCenters;
}


/**
  * @brief draw the center of the armor center by a cross in the image
  * @param img: image for drawing
  * @param size: the size of the cross
  * @param color: the color of the cross
  * @param thickness: the thickness of the cross
  * @return none
  */
void ArmorFind::DrawCross(Mat &img, Point center, int size, Scalar color, int thickness) {
    Point L1, L2, B1, B2;
    int xL = center.x - size > 0 ? center.x - size : 0;
    int xR = center.x + size;
    int yL = center.y - size > 0 ? center.y - size : 0;
    int yR = center.y + size;
    L1 = Point(xL, center.y);
    L2 = Point(xR, center.y);
    B1 = Point(center.x, yL);
    B2 = Point(center.x, yR);
    line(img, L1, L2, color, thickness);
    line(img, B1, B2, color, thickness);

}


/**
  * @brief get the final result of the armor lights
  * @param none
  * @return none
  */
void ArmorFind::GetArmorLights() {
    size_t size = RectfirstResult.size();
    vector<RotatedRect> Groups;
    int cellmaxsize;
    Groups.push_back(RectfirstResult[0]);
    cellmaxsize = RectfirstResult[0].size.height * RectfirstResult[0].size.width;
    if (cellmaxsize > 2500) cellmaxsize = 0;
    int maxsize;

    for (int i = 1; i < size; i++) {
        if (RectfirstResult[i].center.x - RectfirstResult[i - 1].center.x < 10)
        {
            maxsize = RectfirstResult[i].size.height * RectfirstResult[i].size.width;
            if (maxsize > 2500) continue;
            if (maxsize > cellmaxsize) cellmaxsize = maxsize;
            Groups.push_back(RectfirstResult[i]);
        }
        else {
            Armorlists.push_back(Groups);
            CellMaxs.push_back(cellmaxsize);
            cellmaxsize = 0;
            maxsize = 0;
            Groups.clear();
            //if(RectfirstResult[i].size.height * RectfirstResult[i].size.width > 2500) continue;
            Groups.push_back(RectfirstResult[i]);
            cellmaxsize = RectfirstResult[i].size.height * RectfirstResult[i].size.width;
        }
        //std::cout<<"max:"<<cellmaxsize<<std::endl;
        //sizescale = (float)RectfirstResult[i].size.height/(float)RectfirstResult[i].size.width;
        //std::cout<<"scale:"<<sizescale<<" width:"<<RectfirstResult[i].size.width<<std::endl;
    }
    Armorlists.push_back(Groups);
        CellMaxs.push_back(cellmaxsize);
    size = Armorlists.size();
    for (int i = 0; i < size; i++) {
        int Gsize = Armorlists[i].size();
        int GroupMax = CellMaxs[i];
        if (GroupMax > 5) {
            for (int j = 0; j < Gsize; j++) {
                maxsize = Armorlists[i][j].size.height * Armorlists[i][j].size.width;
                if (maxsize == GroupMax) {
                    RectResults.push_back(Armorlists[i][j]);
                }
            }
        }
    }
}

/**
  * @brief get armor centers from lightbar contours
  * @param image: the result will print on this image
  * @param ismono: input 0 for binocular vision process, other for monocular process
  * @return none
  */
void ArmorFind::GetArmors(Mat &image, bool ismono) {
    size_t size = RectResults.size();
    ArmorOldCenters = ArmorCenters;
    ArmorCenters.clear();
    if (size < 2) {
        return;
    }
    Point2f L1, L2;
    float K, angleabs = 0.0, angleL1, angleL2;
    float divscale, areaL1, areaL2;
    float ydis = 0;
    float maxangle, xdis, heightmax, hwdiv;
    Point2f _pt[4], pt[4];

    auto ptangle = [](const Point2f &p1, const Point2f &p2) {
        return fabs(atan2(p2.y - p1.y, p2.x - p1.x)*180.0 / CV_PI);
    };
    auto GetAreaofp3 = [](const Point2f &p1, const Point2f &p2, const Point2f &p3) {
        Mat matrix = (Mat_<double>(3, 3) << p1.x, p2.y, 1, p2.x, p2.y, 1, p3.x, p3.y, 1);
        return 0.5*determinant(matrix);
    };

    for (int i = 0; i < size - 1; i++)
    {
        angleL1 = fabs(RectResults[i].angle);
        L1 = RectResults[i].center;
        areaL1 = RectResults[i].size.height * RectResults[i].size.width;
        RectResults[i].points(_pt);
        /*pt
         * 0 2
         * 1 3
         * */
        if (angleL1 > 45.0) {
            pt[0] = _pt[3];
            pt[1] = _pt[0];
        }
        else {
            pt[0] = _pt[2];
            pt[1] = _pt[3];
        }
        for (int j = i + 1; j < size; j++) {
            L2 = RectResults[j].center;
            if (L1.x != L2.x) {
                K = GetK(L1, L2);
                if (L1.y > L2.y) {
                    ydis = L1.y - L2.y;
                }
                else {
                    ydis = L2.y - L1.y;
                }
                areaL2 = RectResults[j].size.height * RectResults[j].size.width;
                if (areaL1 > areaL2) {
                    divscale = areaL1 / areaL2;
                }
                else {
                    divscale = areaL2 / areaL1;
                }
                angleL2 = fabs(RectResults[j].angle);

                RectResults[j].points(_pt);
                if (angleL2 > 45.0) {
                    pt[2] = _pt[2];
                    pt[3] = _pt[1];
                }
                else {
                    pt[2] = _pt[1];
                    pt[3] = _pt[0];
                }
                maxangle = MAX(ptangle(pt[0], pt[2]), ptangle(pt[1], pt[3]));
                //std::cout<<"angle:"<<maxangle<<std::endl;
               // maxangle = 0;
                if (angleL1 > 45.0 && angleL2 < 45.0) {
                    angleabs = 90.0 - angleL1 + angleL2;
                }
                else if (angleL1 <= 45.0 && angleL2 >= 45.0) {
                    angleabs = 90.0 - angleL2 + angleL1;
                }
                else {
                    if (angleL1 > angleL2) angleabs = angleL1 - angleL2;
                    else angleabs = angleL2 - angleL1;
                }
                xdis = fabs(L1.x - L2.x);
                heightmax = MAX(MAX(RectResults[i].size.width, RectResults[j].size.width), MAX(RectResults[i].size.height, RectResults[j].size.height));
                hwdiv = xdis / heightmax;

                //?��????
                if (fabs(K) < 0.5 && divscale < 3.0 && maxangle < 20.0 && hwdiv < 10.0 && ydis < 0.4*heightmax)
                {//&& ydis < armormin
                    if (angleabs < 7)
                    {
                        if (ismono)
                        {
                            float armor_area = GetAreaofp3(pt[0], pt[1], pt[2]) + GetAreaofp3(pt[1], pt[2], pt[3]);
                            //std::cout<<"area:"<<armor_area<<std::endl;
                            Monodata pushdata;
                            pushdata.area = armor_area;
                            pushdata.center = Point(0.5*(L1.x + L2.x), 0.5*(L1.y + L2.y));
                            if (hwdiv > 5.0) {
                                pushdata.armor = pushdata.big_armor;
                            }
                            else {
                                pushdata.armor = pushdata.small_armor;
                            }
                            monodata.push_back(pushdata);
                            ArmorCenters.push_back(Point(0.5*(L1.x + L2.x), 0.5*(L1.y + L2.y)));


                            ArmorLostDelay = 0;
                        }
                        else {
                            ArmorCenters.push_back(Point(0.5*(L1.x + L2.x), 0.5*(L1.y + L2.y)));
                            ArmorLostDelay = 0;
                        }
                    }
                }
            }
        }
    }
    if (ArmorCenters.size() == 0)
    {
        ArmorLostDelay++;
        if (ArmorLostDelay < 10)
        {
            ArmorCenters = ArmorOldCenters;
        }
    }




}

/**
  * @brief return the slope of the line connected by 2 points
  * @param L1 L2: points input
  * @return slope of the line by these 2 points
  */
double ArmorFind::GetK(Point2f L1, Point2f L2) {
    return (L1.y - L2.y) / (L1.x - L2.x);
}


void ArmorFind::Clear(void) {
    monodata.clear();
    CellMaxs.clear();
    Armorlists.clear();
    RectfirstResult.clear();
    RectResults.clear();
    Target.clear();
    final.clear();
    PairContour.clear();
    centers.clear();
}


void ArmorFind::drawHeart(Mat &dstImage, Point center)
{
    int axis_x, axis_y;
    for (int i = dstImage.rows/3; i < int(dstImage.rows/3*2.5); i++)
        for (int j = dstImage.cols/5*2; j < dstImage.cols/5*3; j++)
        {
            axis_y = center.y - i;
            axis_x = j - center.x;

            //5*pow(x,2)-6*abs(x)*y+5*pow(y,2)==128
            int left = 5 * pow(axis_x, 2) - 6 * abs(axis_x)*axis_y + 5 * pow(axis_y, 2);
            if (left < 1000 && left>600)
            {
                dstImage.at<Vec3b>(i, j)[0] = 0;
                dstImage.at<Vec3b>(i, j)[1] = 0;
                dstImage.at<Vec3b>(i, j)[2] = 255;
            }
        }
}


void ArmorFind::FindStart()
{

    //cap.open("D:\\F_EXPAND\\CppWorkSpace\\AmbitionVison\\AmbitionVison\\sucai\\VisualMaterial\\lancehoumianhei.MOV");

    cap.open(0);
    cap.set(CV_CAP_PROP_FOURCC, CV_FOURCC('M', 'J', 'P', 'G'));//?????MJPG???
    //cap.set(CV_CAP_PROP_FRAME_WIDTH, 1920);
    //cap.set(CV_CAP_PROP_FRAME_HEIGHT, 1080);
    cap.set(CV_CAP_PROP_FRAME_WIDTH, 1280);
    cap.set(CV_CAP_PROP_FRAME_HEIGHT, 720);
    cap.set(CV_CAP_PROP_FPS, 60);
    cap.set(CV_CAP_PROP_EXPOSURE,0);

    //chuankou
    int serial_1 = 1;
    InitSerial(serial_1);
    //waitKey(1000);

    unsigned int frames = 0;//???????
    double time = 0;//???????
    unsigned int roiflagcount = 0;



    cout<<"find armor start"<<endl;


    ArmorPredict Predictor;
    CarData InfantryInput;

    InfantryInput.level = 3;
    InfantryInput.mode = 1;

    while (1)

    {//??????
        double t0 = getTickCount();
        frames++;

        ArmorResult.clear();
        contours.clear();

        cap >> image;
        if (image.empty())
            break;
        /*if (roiflagcount < 30 || roiflagcount % 30 == 0 || Predictor.ifRoiFlag == 0)//30?????????????????????????
        {
            cout<<"??????"<<endl;
            armor_roi = image;
        }
        else
        {
            cout << "???????" << endl;
            armor_roi = image(Predictor.armorRect);
        }
        */
        LightContour(BEATBLUE, image, bbinary, rgThresh, contours);
        process(contours, image, result, ArmorResult, 1);
        Predictor.PredictMono(monodata,1280, t0, InfantryInput.level);
        TransformData(serial_1, Predictor.Data);

        cout<<"dis:"<<Predictor.Data.z.f<<endl;
        cout<<"speed:"<<Predictor.Data.yaw_speed.d<<endl;
        cout<< "yaw:" <<Predictor.Data.yaw_angle.d << endl;
        cout<<"pitch:" <<Predictor.Data.pitch_angle.d << endl<<endl;


        /*namedWindow("result",0);
        namedWindow("binary",0);
        imshow("result", result);
        imshow("binary", bbinary);*/


        if ((char)waitKey(1) == 'q')
            break;




        time += (getTickCount() - t0) / getTickFrequency();
        cout << frames / time << " fps" << endl<<endl;
        roiflagcount++;
    }
    //outputVideo.release();
}
