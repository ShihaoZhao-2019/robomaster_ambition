#include </home/ambitiom/AmbitionVision/v1_1/include/armorpredict.hpp>

float b[3] = {  0.0002414, 0.0004827, 0.0002414};
float a[3] = { 1.0000,  -1.9556, 0.9565} ;

float usart_xBuf[3] = {0, 0, 0};
float usart_yBuf[3] = {0, 0, 0};

float usart_IIRLowPass(float x);
ArmorPredict::ArmorPredict()
{
    /*
    b[0] = 0.0155;
    b[1] = 0.0155;
    b[2] = 0;
    a[0] = 1.0000;
    a[1] = -0.9691;
    a[2] = 0;
    */

    for(int i = 0; i < 3; i++)
    {
        usart_xBuf[i] = usart_yBuf[i] = 0;
    }
	mono_x = 0;
	mono_y = -74.85;
	mono_z = -114.23;
	mono_small_armor_720p_const = 3.225154601204089e+09;
	mono_small_armor_1080p_const = 3.215247173230000e+09;
	mono_big_armor_720p_const = 5.721752804635057e+09;
	mono_big_armor_1080p_const = 5.781835317948425e+09;

	mono_f_720p = 1.0332191162109375e+03;
	mono_f_1080p = 1038.;

	//��Ļ����
	mono_base_720p = 4.6563079833984375e+02;
	mono_base_1080p = 6.4032672119140625e+02;

    //ifRoiFlag = 0;
}

void ArmorPredict::PredictMono(vector<Monodata> &mono_input, int videotype, double time, int robotlevel) {
	//                                              װ����Ϣ     ����ͷģʽ         
	if (mono_input.size() == 0) {
		Data.yaw_angle.d = 0;
		Data.pitch_angle.d = 0;
		return;
	}
	if (time != 0) {
		T_last = T_curr;
		T_curr = time;
		T_between = (double)(T_curr - T_last) / getTickFrequency();//*�������ʱ�䵥λ��   ʱ��������ֻ��/ÿ���ӵ�ʱ��������
		if (T_between > 0.5) T_between = 0;
	}
	int size = mono_input.size();
	for (int i = 0; i < size; i++)
	{
		if (mono_input[i].armor == mono_input[i].small_armor)//small armor
		{
			if (videotype == 1280)//*720P   1280*720
			{
				mono_input[i].distance = sqrtf(mono_small_armor_720p_const / mono_input[i].area);
			}
			else//*1080P   1920*1080
			{
				mono_input[i].distance = sqrtf(mono_small_armor_1080p_const / mono_input[i].area);
			}
		}

		else//big armor
		{
			if (videotype == 1280)
			{
				mono_input[i].distance = sqrtf(mono_big_armor_720p_const / mono_input[i].area);
			}
			else {
				mono_input[i].distance = sqrtf(mono_big_armor_1080p_const / mono_input[i].area);
			}
		}
	}

	std::sort(mono_input.begin(), mono_input.end(), [](const Monodata &d1, const Monodata &d2) {
		return d1.distance < d2.distance;
	});
	//std::cout<<"distance:"<<mono_input[0].distance<<std::endl;


	//����װ������ROI
    /*ifRoiFlag = 0;
	int area = mono_input[0].area;
    std::cout << area << endl;*/

    /*
	if (area != 0)
	{
		ifRoiFlag = 1;
	}

	if (ifRoiFlag == 1)
	{
		//std::cout << "����װ������" << endl;
		armorRect.x = mono_input[0].center.x - 240;
		armorRect.y = mono_input[0].center.x - 135;
		armorRect.height = 480;
		armorRect.width = 270;

		//�޷�
		if (armorRect.x < 0)
		{
			armorRect.x = 0;
		}
		if (armorRect.y < 0)
		{
			armorRect.y = 0;
		}

		if (armorRect.br().x >= 1280 || armorRect.br().y >= 720)
		{
			armorRect.height = 380;
			armorRect.width = 270;
		}

		if (armorRect.br().x >= 1280 || armorRect.br().y >= 720)
		{
			armorRect.height = 280;
			armorRect.width = 170;
		}
		if (armorRect.br().x >= 1920 || armorRect.br().y >= 1080)
		{
			ifRoiFlag = 0;
		}

    }*/


	float cal_x, cal_y;
	if (videotype == 1280)
	{
		cal_x = (mono_input[0].center.x - 640)*mono_input[0].distance / mono_f_720p;
		cal_y = (mono_base_720p - mono_input[0].center.y)*mono_input[0].distance / mono_f_720p;
	}
	else
	{
		cal_x = (mono_input[0].center.x - 960)*mono_input[0].distance / mono_f_1080p;
		cal_y = (mono_base_1080p - mono_input[0].center.y)*mono_input[0].distance / mono_f_1080p;
	}
	//std::cout<<"x:"<<cal_x<<" y:"<<cal_y<<std::endl;

	float last_x = mono_Pos.x;
	mono_Pos.x = cal_x - mono_x;
	mono_Pos.y = cal_y - mono_y;
	mono_Pos.z = mono_input[0].distance - mono_z;
	if (mono_Pos.z <= 0) return;
	int16_t yangle = (int16_t)(-atan(mono_Pos.x / mono_Pos.z)*1303.7972938);
	Data.yaw_speed.d = 0;
	if (T_between != 0 && time != 0 && Data.yaw_angle.d != 0) {
		Data.yaw_speed.d = yangle - Data.yaw_angle.d;
		if (abs(last_x - mono_Pos.x) < 4) Data.yaw_speed.d = 0;
	}


	Data.yaw_angle.d = yangle;
    //cout<<"yangle "<< yangle<<"\n";
    //lvbo
    //Data.yaw_angle.d = usart_IIRLowPass(Data.yaw_angle.d);


    Data.pitch_angle.d = (int16_t)(atan(mono_Pos.y / mono_Pos.z)*1303.7972938);
	Data.shoot_speed.f = 0;
	Data.z.f = mono_input[0].distance;

}

float usart_IIRLowPass(float x)
{
    int i;
    //����֮ǰBuf��ǰ�ƶ�һ��λ�ã��Ա���֮ǰBuf�����ݣ�
    for(i = 2; i > 0; i--)
    {
        usart_yBuf[i] = usart_yBuf[i-1];
        usart_xBuf[i] = usart_xBuf[i-1];
    }
    usart_xBuf[0] = x;
    usart_yBuf[0] = 0;
    for(i = 1;i < 3;i++)
    {
        usart_yBuf[0] = usart_yBuf[0] + b[i]*usart_xBuf[i];
        usart_yBuf[0] = usart_yBuf[0] - a[i]*usart_yBuf[i];
    }
    usart_yBuf[0] = usart_yBuf[0] + b[0]*usart_xBuf[0];
//    cout<<usart_yBuf[0]<<"\n\n";
    return usart_yBuf[0];
}
