#include "main.h"

uint64_t fireFlag = 0;
int16_t last_shift = 0;
int16_t now_shift = 0;

void fireMotor_stop()
{
	TIM4->CCR1 = 1000;
	TIM4->CCR2 = 1000;
}


void fireMotor_fire()
{
//	TIM4->CCR1 = leftFireMotor;
//	TIM4->CCR2 = rightFireMotor;
	TIM4->CCR1 = 1300;
	TIM4->CCR2 = 1300;
}

void fireMotor()
{
	now_shift = rc.Shift ;
	if(now_shift == 1 && last_shift == 0)
		fireFlag++;
	if(fireFlag % 2 == 1)
		fireMotor_fire();
	else 
		fireMotor_stop();
	last_shift = now_shift;
//	TIM4->CCR1 = fireFlag;
//	TIM4->CCR2 = fireFlag;
}
