#include "main.h"

Angle t_angle = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};


//��̨���pid������ʼ��
void angle_init(struct Angle *angle)//����MPUλ�ø�
{
	angle->back_flag = 0;//��־λ��ʼ��
	angle->yaw_set = real_angle.yaw;
	angle->pitch_set = real_angle.pitch;//��ȡ��ʵֵ		//��λ//������ֵλ��ֵת����mpu�Ƕ�ֵ
	angle->pitch_target = PITCH_MECHANICAL_CENTRE + (90 - (-GMPitchEncoder.init_angle));
	angle->yaw_target = YAW_MECHANICAL_CENTRE + (90 - GMYawEncoder.init_angle);
	
}
//uint64_t presstime = 0;
//��̨��������趨ֵ
void angle_set_update(struct Angle *angle)
{
	if(angle->back_flag == 0)//������������//��еλ��
	{
		if(((int)angle->yaw_set != (int)angle->yaw_target) || ((int)angle->pitch_set != (int)angle->pitch_target))
		{
			angle->yaw_set = angle->yaw_set < angle->yaw_target ? angle->yaw_set + 0.1f : angle->yaw_set - 0.1f;
			angle->pitch_set = angle->pitch_set < angle->pitch_target ? angle->pitch_set + 0.1f : angle->pitch_set - 0.1f;
		}
		else
			angle->back_flag = 1;	
	}
	else
	{	
		//yaw�᲻��λ
		angle->yaw_set += rc.L_x / 1500.0f - (rc.mouse_x / 100.0f);
		//pitch�������λ
		angle->pitch_remote_last = angle->pitch_remote_now;
		angle->pitch_remote_now += rc.L_y / 2000.0f + rc.mouse_y / 133.0f;
		angle->pitch_differ = angle->pitch_remote_now - angle->pitch_remote_last;
		
	   if(-GMPitchEncoder.ecd_angle >= PITCH_MECHANICAL_LOW && angle->pitch_differ < 0)
			angle->pitch_set +=  (angle->pitch_differ);
		 
	   if(-GMPitchEncoder.ecd_angle <= PITCH_MECHANICAL_TOP && angle->pitch_differ > 0)
			angle->pitch_set +=  (angle->pitch_differ);
	   
	   if(-GMPitchEncoder.ecd_angle < PITCH_MECHANICAL_LOW && -GMPitchEncoder.ecd_angle > PITCH_MECHANICAL_TOP)
		
		angle->pitch_set +=  angle->pitch_differ;
	}
}
//��̨��������������ֵ
void angle_out_update(struct Angle *angle)
{
	//�趨ֵ����
	//Shoot();
	angle_set_update(angle);
	
	//pid�������ֵ
	out[YAW_ANGLE] = Calculate_Current_Value(&pid[YAW_ANGLE], angle->yaw_set, real_angle.yaw);		
	out[YAW_SPEED] = Calculate_Current_Value(&pid[YAW_SPEED], out[YAW_ANGLE], real_angle.gz);
	out[PITCH_ANGLE] = Calculate_Current_Value(&pid[PITCH_ANGLE], angle->pitch_set, real_angle.pitch);
	out[PITCH_SPEED] = Calculate_Current_Value(&pid[PITCH_SPEED], out[PITCH_ANGLE], real_angle.gx);
	
	Set_CloudMotor_Current(-(int16_t)out[YAW_SPEED],(int16_t)out[PITCH_SPEED]);
}

void Set_CloudMotor_Current(int16_t gimbal_yaw_iq, int16_t gimbal_pitch_iq)//��̨����������ͺ���//CAN1���ͺ���
{
    CanTxMsg tx_message;    
    tx_message.StdId = 0x1FF;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = (unsigned char)(gimbal_yaw_iq >> 8);
    tx_message.Data[1] = (unsigned char)gimbal_yaw_iq;
    tx_message.Data[2] = (unsigned char)(gimbal_pitch_iq >> 8);
    tx_message.Data[3] = (unsigned char)gimbal_pitch_iq;
		tx_message.Data[4] = 0x00;
    tx_message.Data[5] = 0x00;
    tx_message.Data[6] = 0x00;
    tx_message.Data[7] = 0x00;
    CAN_Transmit(CAN1,&tx_message);
}

