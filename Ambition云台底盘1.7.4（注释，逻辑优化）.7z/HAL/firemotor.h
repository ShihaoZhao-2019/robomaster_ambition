#ifndef _FIREMOTOR_H_
#define _FIREMOTOR_H_
#include "stm32f4xx.h"
void fireMotor_stop(void);
void fireMotor_fire(void);
void fireMotor(void);

#endif






