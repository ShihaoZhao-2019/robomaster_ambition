#include "main.h"

Feed_set feed_set = {0, 0, 0, 0};
Feed_Motor_State feed_state = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

void Shoot()
{
	feed_state.now_mouse_l = rc.mouse_l;
	if(feed_state.now_mouse_l == 1 && feed_state.last_mouse_l == 0)//����
	{
		feed_state.pressState = 1;
		feed_set.feed_angle_set += SingleBall;
		//feed_state.dance_flag = 0;
	}
	else if(feed_state.now_mouse_l == 1 && feed_state.last_mouse_l == 1)//����
	{
		feed_state.pressState = 2;
		feed_set.feed_speed_set = 500;
	}
	else if(feed_state.now_mouse_l == 0 && feed_state.last_mouse_l == 0)//ͣ
	{
		feed_state.pressState = 0;
		
	}
	feed_state.last_mouse_l = feed_state.now_mouse_l;
	feed_state.now_Jam = IfJam2(feed_state.pressState);//��⿨��
	
	if(feed_state.last_Jam == 0 && feed_state.now_Jam == 1)
	{
		feed_state.pressState = 1;//λ�û�����
		
		feed_set.feed_angle_set = feed_set.feed_angle_real - SingleBall;
		
		feed_state.jamTime_1ms = 0;//��⿨����ʼ��
	}
	feed_state.last_Jam = feed_state.now_Jam;
	switch(feed_state.pressState)//���
	{
		case 1 : feed_state.press_number = 1;
						 feed_state.presstime_1ms = 0;
						 fireMotorDoubleLoopPid_out_update();
						 //feed_state.dance_flag = 0;
						 break;
		
		case 2 : feed_state.presstime_1ms ++;//��ס150*2ms�� �ٶȻ����
						 if(feed_state.presstime_1ms > 150)
						 {
							feed_state.press_number++;
							feed_set.feed_angle_set = 0;
							feed_state.sum_angle = (int)feed_set.feed_angle_real;
							fireMotorSingleLoopPid_out_update();
							feed_state.dance_flag = 1;					 
						 }
						 else
						 {
							 fireMotorDoubleLoopPid_out_update();
						 }
						 break;
						 
//		case 3 : feed_state.press_number = 1;
//						 fireMotorDoubleLoopPid_out_update();
//						 break;
		case 0 : if(feed_state.press_number == 1)
								fireMotorDoubleLoopPid_out_update();//λ�û� �����ɿ�ʱ���
					   else if(feed_state.press_number != 1)//�ٶȻ��ɿ�ʱ ��λ
					   {
								feed_set.feed_speed_set = 0;
	//					feed_state.next_angle = ((feed_state.sum_angle / SingleBall) + 1) * SingleBall;
	//					feed_set.feed_angle_set = feed_state.next_angle;
								feed_set.feed_angle_set = ((feed_state.sum_angle / SingleBall) + 1) * SingleBall;
								fireMotorDoubleLoopPid_out_update();
					   }
						 feed_state.presstime_1ms = 0;
						 feed_state.dance_flag = 0;
						 break;
	}
	
	feed_state.if_dance = Judge_Dance();
}
int16_t Judge_Dance()
{
	if((feed_state.dance_flag == 1) && (feed_state.last_dance_flag == 0))
	{
		feed_state.last_dance_flag = feed_state.dance_flag;
		return 1;
	}
	else if((feed_state.dance_flag == 0) && (feed_state.last_dance_flag == 1))
	{
		feed_state.last_dance_flag = feed_state.dance_flag;
		return 2;
	}
	feed_state.last_dance_flag = feed_state.dance_flag;
	return 0;
}
int16_t IfJam2(int16_t state)
{
	if(state == 1 || state == 0)
	{
		if(fabs(feed_set.feed_angle_real - feed_set.feed_angle_set) >= Feed_Angle_Err)//����ֵ
			feed_state.jamTime_1ms++;
		else 
			feed_state.jamTime_1ms = 0;
		if(feed_state.jamTime_1ms > 200)//200*2ms���ж��ǿ���
			return 1;

	}
	else if(state == 2)
	{
		if(fabs(feed_set.feed_speed_real - feed_set.feed_speed_set) >= Feed_Speed_Err)
			feed_state.jamTime_1ms++;
		else 
			feed_state.jamTime_1ms = 0;
		if(feed_state.jamTime_1ms > 200)
			return 1;

	}
	return 0;
}

void fireMotorPidReal_update(void)
{
	feed_set.feed_angle_real = CMFeedEncoder.ecd_angle;
	feed_set.feed_speed_real = CMFeedEncoder.filter_rate;
}
void fireMotorSingleLoopPid_out_update(void)
{
	fireMotorPidReal_update();//��ʵֵ����
	out[FEED_MOTOR_SINGLE] = Calculate_Current_Value(&pid[FEED_MOTOR_SINGLE], feed_set.feed_speed_set, feed_set.feed_speed_real);
	Set_FeedMotor_Current((int16_t)out[FEED_MOTOR_SINGLE]);
}

void fireMotorDoubleLoopPid_out_update(void)
{
	fireMotorPidReal_update();
	out[FEED_MOTOR_DOUBLE_ANGLE] = Calculate_Current_Value(&pid[FEED_MOTOR_DOUBLE_ANGLE], feed_set.feed_angle_set, feed_set.feed_angle_real);
	Set_FeedMotor_Current((int16_t)out[FEED_MOTOR_DOUBLE_ANGLE]);
}

void Set_FeedMotor_Current(int16_t feed_motor_iq)//��������������ͺ���//CAN2���ͺ���
{
    CanTxMsg tx_message;    
    tx_message.StdId = 0x1FF;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = 0x00;
    tx_message.Data[1] = 0x00;
    tx_message.Data[2] = 0x00;
    tx_message.Data[3] = 0x00;
	tx_message.Data[4] = (unsigned char)(feed_motor_iq >> 8);
    tx_message.Data[5] = (unsigned char)feed_motor_iq;
    tx_message.Data[6] = 0x00;
    tx_message.Data[7] = 0x00;
    CAN_Transmit(CAN2,&tx_message);
}

