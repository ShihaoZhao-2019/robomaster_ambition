#ifndef _CHASSISMOTOR_H_
#define _CHASSISMOTOR_H_

#include "delay.h"
#define keypad_K 2
#define remote_K 1.6
#define limit 1012
void chassis_set_update(void);
void chassis_out_update(void);
void mecanum_Resolving(float *a ,float *b,float *c,float *d,int z);    //���׽���
void Chassis_fllow(float *x, float *y);
void remote_fifo(void);
void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq);	//���̵���������ͺ���


typedef struct Chassis_set
{
	
	float cm1_set;
	float cm2_set;
	float cm3_set;
	float cm4_set;
	
	float cm1_real;
	float cm2_real;
	float cm3_real;
	float cm4_real;
	float follow_set;
	float follow_real;
	
}Chassis_set;
void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq);
//volatile Chassis_set chassis_set;
#endif
