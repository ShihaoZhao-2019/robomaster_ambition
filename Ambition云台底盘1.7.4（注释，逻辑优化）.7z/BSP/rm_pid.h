#ifndef		_RM_PID_H_
#define		_RM_PID_H_

#include "delay.h"
//�궨��pid�ṹ�������±�
//#define FL 0 
//#define FR 1
//#define BL 2
//#define BR 3
//#define PITCH_ANGLE 4
//#define PITCH_SPEED 5
//#define YAW_ANGLE  6
//#define YAW_SPEED 7
//#define ALL_PID 8

#define FR 0
#define FL 1
#define BL 2
#define BR 3
#define PITCH_ANGLE 4
#define PITCH_SPEED 5
#define YAW_ANGLE  6
#define YAW_SPEED 7
#define CHASSIS_FOLLOW 8

#define FEED_MOTOR_SINGLE 9

#define FEED_MOTOR_DOUBLE_ANGLE 10
#define FEED_MOTOR_DOUBLE_SPEED 11
#define ALL_PID 12
typedef struct PID
{
	float kp;
	float ki;
	float kd;
	
	float pout;
	float iout;
	float dout;
	
	float poutmax;
	float ioutmax;
	float doutmax;
	float outmax;
	
	float set;
	float real;
	float out;
	
	float err;							//����ƫ��ֵ
	float err_last;					//��һ��ƫ��ֵ
	float err_llast;				//���ϴ�ƫ��ֵ
	float integral;					//�ۼ�ƫ��ֵ
	void(*f_pid_init)(struct PID *pid, float kp, float ki, float kd, float poutmax, float ioutmax, float doutmax, float outmax);			//������ʼ��pid
	void(*f_pid_reset)(struct PID *pid);
}PID;

extern PID pid[ALL_PID];
extern float out[ALL_PID];
static void pid_init(PID *pid, float kp, float ki, float kd, float poutmax, float ioutmax, float doutmax, float outmax);
static void pid_reset(PID *pid);

void All_Pid_Configuration(PID pid[]);
float Calculate_Current_Value(PID *pid, float set, float real);
void Look(void);


#endif
