#ifndef __CAN2_H_
#define __CAN2_H_
#include "delay.h"

void CAN2_Configure(void);				//can2��ʼ��

#endif
