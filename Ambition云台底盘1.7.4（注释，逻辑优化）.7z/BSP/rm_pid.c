#include "main.h"

PID pid[ALL_PID];		//��������PID�ṹ������
float out[ALL_PID] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};//PID���ֵ����


//pidֵ��ʼ��
static void pid_init(PID *pid, float kp, float ki, float kd, float poutmax, float ioutmax, float doutmax, float outmax)
{	
	pid->kp = kp;
	pid->ki = ki;
	pid->kd = kd;
	
	pid->poutmax = poutmax;
	pid->ioutmax = ioutmax;
	pid->doutmax = doutmax;
	pid->outmax = outmax;
	
	pid->f_pid_reset = pid_reset;
	pid->f_pid_reset(pid);
	
	pid->err = 0;
	pid->err_last = 0;
	pid->err_llast = 0;
	pid->integral = 0;
	
	
}
//pid���ֵ����
static void pid_reset(PID *pid)
{
	
	pid->pout = 0;
	pid->iout = 0;
	pid->dout = 0;
	pid->out  = 0;
	
}
//���е��pidֵ��ʼ�����β���Ҫ�������ģ���һ�β����β�ȫΪ0��
//(&pid[i], kp, ki, kd, poutmax, ioutmax, doutmax, outmax)
void All_Pid_Configuration(PID pid[])
{	
	pid[FR].f_pid_init = pid_init;
	//pid[FR].f_pid_init(&pid[FR], 0, 0, 0, 0, 0, 0, 0);	//��ǰ
	pid[FR].f_pid_init(&pid[FR], 65.0f, 0.5f, 0.8f, 5000.0f, 500.0f, 1000.0f, 6000.0f);  //��ǰ
	
	pid[FL].f_pid_init = pid_init;
	pid[FL].f_pid_init(&pid[FL], 65.0f, 0.5f, 0.8f, 5000.0f, 500.0f, 1000.0f, 6000.0f);  //��ǰ
	
	pid[BL].f_pid_init = pid_init;
	//pid[BL].f_pid_init(&pid[BL], 0, 0, 0, 0, 0, 0, 0);
	pid[BL].f_pid_init(&pid[BL], 65.0f, 0.5f, 0.8f, 5000.0f, 500.0f, 1000.0f, 6000.0f);  //��ǰ

	pid[BR].f_pid_init = pid_init;
	//pid[BR].f_pid_init(&pid[BR], 0, 0, 0, 0, 0, 0, 0);
	pid[BR].f_pid_init(&pid[BR], 65.0f, 0.5f, 0.8f, 5000.0f, 500.0f, 1000.0f, 6000.0f);  //��ǰ
	
	pid[PITCH_ANGLE].f_pid_init = pid_init;
	//pid[PITCH_ANGLE].f_pid_init(&pid[PITCH_ANGLE], 0, 0, 0, 0, 0, 0, 0);
	pid[PITCH_ANGLE].f_pid_init(&pid[PITCH_ANGLE], 9.0f, 0.0f, 5.0f, 50.0f, 0.0f, 10.0f, 50.0f);
	
	pid[PITCH_SPEED].f_pid_init = pid_init;
	//pid[PITCH_SPEED].f_pid_init(&pid[PITCH_SPEED], 0, 0, 0, 0, 0, 0, 0);
	pid[PITCH_SPEED].f_pid_init(&pid[PITCH_SPEED], 200.0f, 0.0f, 180.0f, 5000.0f, 0.0f, 1000.0f, 5000.0f);
	
	pid[YAW_ANGLE].f_pid_init = pid_init;
	//pid[YAW_ANGLE].f_pid_init(&pid[YAW_ANGLE], 0, 0, 0, 0, 0, 0, 0);
	//pid[YAW_ANGLE].f_pid_init(&pid[YAW_ANGLE], 1.0f, 0.0f, 1.0f, 5000.0f, 0.0f, 100.0f, 5000.0f);
	pid[YAW_ANGLE].f_pid_init(&pid[YAW_ANGLE], 2.5f, 0.0f, 1.0f, 50.0f, 0.0f, 10.0f, 50.0f);
	
	pid[YAW_SPEED].f_pid_init = pid_init;
	//pid[YAW_SPEED].f_pid_init(&pid[YAW_SPEED], 0, 0, 0, 0, 0, 0, 0);
	//pid[YAW_SPEED].f_pid_init(&pid[YAW_SPEED], 400.0f, 0.0f, 10.0f, 5000.0f, 0.0f, 1000.0f, 6000.0f);
	pid[YAW_SPEED].f_pid_init(&pid[YAW_SPEED], 600.0f, 0.0f, 250.0f, 5000.0f, 0.0f, 1000.0f, 5000.0f);
	
	pid[CHASSIS_FOLLOW].f_pid_init = pid_init;
	pid[CHASSIS_FOLLOW].f_pid_init(&pid[CHASSIS_FOLLOW], 30.0f, 0.0f, 0.0f, 1000.0f, 0.0f, 0.0f, 1000.0f);
	
	pid[FEED_MOTOR_SINGLE].f_pid_init = pid_init;
	pid[FEED_MOTOR_SINGLE].f_pid_init(&pid[FEED_MOTOR_SINGLE], 80.0f, 0.0f, 0.0f, 5000.0f, 0.0f, 0.0f, 5000.0f);
	
	pid[FEED_MOTOR_DOUBLE_ANGLE].f_pid_init = pid_init;
	//pid[FEED_MOTOR_DOUBLE_ANGLE].f_pid_init(&pid[FEED_MOTOR_DOUBLE_ANGLE], 2.5f, 0.0f, 0.0f, 800.0f, 0.0f, 10.0f, 800.0f);
	pid[FEED_MOTOR_DOUBLE_ANGLE].f_pid_init(&pid[FEED_MOTOR_DOUBLE_ANGLE], 12.5f, 0.0f, 100.0f, 5000.0f, 0.0f, 5000.0f, 5000.0f);
	
//	pid[FEED_MOTOR_DOUBLE_SPEED].f_pid_init = pid_init;
//	pid[FEED_MOTOR_DOUBLE_SPEED].f_pid_init(&pid[FEED_MOTOR_DOUBLE_SPEED], 80.0f, 0.0f, 0.0f, 5000.0f, 0.0f, 0.0f, 5000.0f);
}

//pid��������ֵ 
float Calculate_Current_Value(PID *pid, float set, float real)
{
	//����������һ�ε����ֵ
	pid->f_pid_reset = pid_reset;
	pid->f_pid_reset(pid);
	
	pid->set = set ;
	pid->real = real;
	
	pid->err_last = pid->err;
	pid->err = pid->set - pid->real;
	pid->integral += pid->err;
	
	pid->pout = pid->kp * pid->err;
	pid->pout = pid->pout < pid->poutmax ? pid->pout : pid->poutmax;
	pid->pout = pid->pout > -pid->poutmax ? pid->pout : -pid->poutmax;
	
	pid->iout = pid->ki * pid->integral;
	pid->iout = pid->iout < pid->ioutmax  ? pid->iout : pid->ioutmax;
	pid->iout = pid->iout > -pid->ioutmax ? pid->iout : -pid->ioutmax;
	
	pid->dout = pid->kd * (pid->err - pid->err_last);
	pid->dout = pid->dout < pid->doutmax ? pid->dout : pid->doutmax;
	pid->dout = pid->dout > -pid->doutmax ? pid->dout : -pid->doutmax;
	
	pid->out = pid->pout + pid->iout + pid->dout;
	pid->out = pid->out < pid->outmax ? pid->out : pid->outmax;
	pid->out = pid->out > -pid->outmax ? pid->out : -pid->outmax;
	//Look();//����ֵ
	return pid->out;
}
float sset , rreal , oout ;
void Look(void)
{
	sset = pid[FEED_MOTOR_SINGLE].set;
	rreal = pid[FEED_MOTOR_SINGLE].real;
	oout = pid[FEED_MOTOR_SINGLE].out;
}
