#include "main.h"

#define GYRO_FSR 2 //陀螺仪量程设置0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
#define ACCEL_FSR 0 //加速度计量程设置0,±2g;1,±4g;2,±8g;3,±16g
#define MPU_RATE 1000 //采样频率
volatile packed_angle real_angle = {0, 0, 0, 0};
MagMaxMinData_t MagMaxMinData;
MagCaliStruct_t MagSavedCaliData = {140,85,-15,1.0,0.85,0.375,0};
GyroCaliStruct_t GyroSavedCaliData;     	    //gyro offset data
AccCaliStruct_t AccSavedCaliData; 
ADJUST adjust;

uint8_t mpu_buf[15]={0};  
volatile MPU6050_RAW_DATA    MPU6050_Raw_Data;    //原始数据
volatile MPU6050_REAL_DATA   MPU6050_Real_Data;
AHRS ahrs;
float Gyro_z_err = 0.0f;
float Gyro_x_err = 0.0f;
float Gyro_y_err = 0.0f;

int16_t MPU6050_FIFO[6][11] = {0};//[0]-[9]为最近10次数据 [10]为10次数据的平均值

u8  MPU6050_is_DRY = 1;

volatile float exInt, eyInt, ezInt;  // 误差积分
volatile float q0 = 1.0f;
volatile float q1 = 0.0f;
volatile float q2 = 0.0f;
volatile float q3 = 0.0f;

volatile float mygetqval[6];	//用于存放传感器转换结果的数组
static volatile float gx, gy, gz, ax, ay, az;   //作用域仅在此文件中
static volatile float q[4]; //　四元数
volatile uint32_t lastUpdate, now; // 采样周期计数 单位 us
volatile float angle[3] = {0};
volatile float yaw_temp,pitch_temp,roll_temp;
volatile float last_yaw_temp,last_pitch_temp,last_roll_temp;
volatile float yaw_angle,pitch_angle,roll_angle; //使用到的角度值
volatile float Yaw_angle_sum_gz = 0;
volatile float Pitch_angle_sum_gx = 0;
double halfT;
// Fast inverse square-root
/**************************实现函数********************************************
*函数原型:	   float invSqrt(float x)
*功　　能:	   快速计算 1/Sqrt(x) 	
输入参数： 要计算的值
输出参数： 结果
*******************************************************************************/
float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}//快速求平方根算法


u8 IMU_Configure()
{

	u8 res;
	MPU_IIC_Init();//初始化IIC总线
	
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X80);	//复位MPU6050
	delay_ms(100);
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X00);	//唤醒MPU6050 
	MPU_Write_Byte(MPU_GYRO_CFG_REG,0x10);//陀螺仪量程设置0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
	MPU_Write_Byte(MPU_ACCEL_CFG_REG,0x00);//加速度计量程设置0,±2g;1,±4g;2,±8g;3,±16g
	MPU_Write_Byte(MPU_SAMPLE_RATE_REG,1000/MPU_RATE-1);					//设置采样率
	MPU_Write_Byte(MPU_INT_EN_REG,0X00);	//关闭所有中断
	MPU_Write_Byte(MPU_USER_CTRL_REG,0X00);	//I2C主模式关闭
	MPU_Write_Byte(MPU_FIFO_EN_REG,0X00);	//关闭FIFO
	MPU_Write_Byte(MPU_INTBP_CFG_REG,0X02);	//INT引脚低电平有效
	MPU_Write_Byte(MPU_INT_EN_REG,0X01);//使能数据就绪中断
//	MPU_Write_Byte(MPU_CFG_REG,0x01);
	
	res=MPU_Read_Byte(MPU_DEVICE_ID_REG);
	if(res==MPU_ADDR)//器件ID正确
	{
		MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X01);	//设置CLKSEL,PLL X轴为参考
		MPU_Write_Byte(MPU_PWR_MGMT2_REG,0X00);	//加速度与陀螺仪都工作
		MPU_Write_Byte(MPU_SAMPLE_RATE_REG,1000/MPU_RATE-1);		//设置采样率
		
		delay_ms(500);
		MPU6050_Calibration();
		
	}else return 1;
	return 0;
}

//中断线配置
void IMU_INT_Configure()
{
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);//使能GPIOA
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);//使能SYSCFG时钟

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//普通输入模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//100M
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉	 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;// | GPIO_Pin_1;
	GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA2

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource2);//PA2 连接到中断线0
	/* 配置EXTI_Line3 */
	EXTI_InitStructure.EXTI_Line = EXTI_Line2;//LINE2
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;//使能LINE3
	EXTI_Init(&EXTI_InitStructure);//配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;//外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);//配置
}

void MPU6050_Calibration()
{
	int16_t gx,gy,gz;
	int16_t gz_sum = 0,gy_sum = 0,gx_sum = 0;
	float gz_sum_f = 0, gx_sum_f = 0, gy_sum_f = 0;
	int16_t z_max = 0, z_min = 32767;
	int16_t x_max = 0, x_min = 32767;
	int16_t y_max = 0, y_min = 32767;
	for(int i = 0; i < 20; i++)
	{
		MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
		gx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
		gy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
		gz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
		delay_us(1000);
		if(gz > z_max)
			z_max = gz;
		else if(gz < z_min)
			z_min = gz;
		if(gx > x_max)
			x_max = gx;
		else if(gx < x_min)
			x_min = gx;
		if(gy > y_max)
			y_max = gy;
		else if(gy < y_min)
			y_min = gy;
	}
	GyroSavedCaliData.GyroXOffset = (int16_t)(x_max+x_min)/2;
	GyroSavedCaliData.GyroYOffset = (int16_t)(y_max+y_min)/2;
	GyroSavedCaliData.GyroZOffset = (int16_t)(z_max+z_min)/2;
	for(int i = 0; i < 20; i++)
	{
		for(int j = 0; j < 20; j++)
		{
			MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
			gx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
			gy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
			gz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
			gz_sum = gz_sum + gz - GyroSavedCaliData.GyroZOffset;
			gy_sum = gy_sum +gy - GyroSavedCaliData.GyroYOffset;
			gx_sum = gx_sum +gx - GyroSavedCaliData.GyroXOffset;
			delay_us(500);
		}			
		
		if(gz_sum>0)
			GyroSavedCaliData.GyroZOffset += ((20-i)/2+1);
		else if(gz_sum<0)
			GyroSavedCaliData.GyroZOffset -= ((20-i)/2+1);
		gz_sum = 0;
		
		if(gx_sum>0)
			GyroSavedCaliData.GyroXOffset += ((20-i)/2+1);
		else if(gx_sum<0)
			GyroSavedCaliData.GyroXOffset -= ((20-i)/2+1);
		gx_sum = 0;
		
		if(gy_sum>0)
			GyroSavedCaliData.GyroYOffset += ((20-i)/2+1);
		else if(gy_sum<0)
			GyroSavedCaliData.GyroYOffset -= ((20-i)/2+1);
		gy_sum = 0;
		
		
	}
	for(int i = 0; i < 20; i++)
	{
		for(int j = 0; j < 30; j++)
		{
			MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
			gx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
			gy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
			gz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
			
			gx_sum_f += ((float)(gx - GyroSavedCaliData.GyroXOffset)/32.8f - Gyro_x_err);	
			gy_sum_f += ((float)(gy - GyroSavedCaliData.GyroYOffset)/32.8f - Gyro_y_err);	
			gz_sum_f += ((float)(gz - GyroSavedCaliData.GyroZOffset)/32.8f - Gyro_z_err);	
			delay_us(500);
		}			
		
		if(gz_sum_f>0)
			Gyro_z_err += 0.0011f*((float)(20-i)/2.0f);
		else if(gz_sum_f<0)
			Gyro_z_err -= 0.0012f*((float)(20-i)/2.0f);
		gz_sum_f = 0;
	
		if(gx_sum_f>0)
			Gyro_x_err += 0.0011f*((float)(20-i)/2.0f);
		else if(gx_sum_f<0)
			Gyro_x_err -= 0.0012f*((float)(20-i)/2.0f);
		gx_sum_f = 0;
		
		if(gy_sum_f>0)
			Gyro_y_err += 0.0011f*((float)(20-i)/2.0f);
		else if(gy_sum_f<0)
			Gyro_y_err -= 0.0012f*((float)(20-i)/2.0f);
		gy_sum_f = 0;
	}
}
/**********************************************************************************/
/*将MPU6050_ax,MPU6050_ay, MPU6050_az,MPU6050_gx, MPU6050_gy, MPU6050_gz处理后存储*/
/**********************************************************************************/
void MPU6050_DataSave(int16_t ax,int16_t ay,int16_t az,int16_t gx,int16_t gy,int16_t gz) //[0]-[9]为最近10次数据 [10]为10次数据的平均值
{
	uint8_t i = 0;
	int32_t sum=0;
	
	for(i=1;i<10;i++)
	{
		MPU6050_FIFO[0][i-1]=MPU6050_FIFO[0][i];
		MPU6050_FIFO[1][i-1]=MPU6050_FIFO[1][i];
		MPU6050_FIFO[2][i-1]=MPU6050_FIFO[2][i];
		MPU6050_FIFO[3][i-1]=MPU6050_FIFO[3][i];
		MPU6050_FIFO[4][i-1]=MPU6050_FIFO[4][i];
		MPU6050_FIFO[5][i-1]=MPU6050_FIFO[5][i];
	}
	
	MPU6050_FIFO[0][9]=ax;//将新的数据放置到 数据的最后面
	MPU6050_FIFO[1][9]=ay;
	MPU6050_FIFO[2][9]=az;
	MPU6050_FIFO[3][9]=gx;
	MPU6050_FIFO[4][9]=gy;
	MPU6050_FIFO[5][9]=gz;
	
	for(i=0;i<10;i++)//求当前数组的合，再取平均值
	{	
		 sum+=MPU6050_FIFO[0][i];
	}
	MPU6050_FIFO[0][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[1][i];
	}
	MPU6050_FIFO[1][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[2][i];
	}
	MPU6050_FIFO[2][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[3][i];
	}
	MPU6050_FIFO[3][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[4][i];
	}
	MPU6050_FIFO[4][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[5][i];
	}
	MPU6050_FIFO[5][10]=sum/10;
	
}


int16_t MPU6050_Lastax,MPU6050_Lastay,MPU6050_Lastaz
				,MPU6050_Lastgx,MPU6050_Lastgy,MPU6050_Lastgz;
/**************************实现函数********************************************
*函数原型:		void MPU6050_getMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz) {
*功　　能:	    读取 MPU6050的当前测量值
*******************************************************************************/
void MPU6050_getMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz) {
//	if(HMC5883_is_DRY)
//	{
//		
//	}
	if(MPU6050_is_DRY)
	{
		MPU6050_is_DRY = 0;
		MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
		MPU6050_Lastax=(((int16_t)mpu_buf[0]) << 8) | mpu_buf[1];
		MPU6050_Lastay=(((int16_t)mpu_buf[2]) << 8) | mpu_buf[3];
		MPU6050_Lastaz=(((int16_t)mpu_buf[4]) << 8) | mpu_buf[5];
		//跳过温度ADC
		MPU6050_Lastgx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
		MPU6050_Lastgy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
		MPU6050_Lastgz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
			
		MPU6050_DataSave(MPU6050_Lastax,MPU6050_Lastay,MPU6050_Lastaz,MPU6050_Lastgx,MPU6050_Lastgy,MPU6050_Lastgz);  		
		*ax = MPU6050_FIFO[0][10];
		*ay = MPU6050_FIFO[1][10];
		*az = MPU6050_FIFO[2][10];
		*gx = MPU6050_FIFO[3][10] - GyroSavedCaliData.GyroXOffset;
		*gy = MPU6050_FIFO[4][10] - GyroSavedCaliData.GyroYOffset;
		*gz = MPU6050_FIFO[5][10] - GyroSavedCaliData.GyroZOffset;
	} 
	else
	{       //读取上一次的值
		*ax = MPU6050_FIFO[0][10];//=MPU6050_FIFO[0][10];
		*ay = MPU6050_FIFO[1][10];//=MPU6050_FIFO[1][10];
		*az = MPU6050_FIFO[2][10];//=MPU6050_FIFO[2][10];
		*gx = MPU6050_FIFO[3][10] - GyroSavedCaliData.GyroXOffset;//=MPU6050_FIFO[3][10];
		*gy = MPU6050_FIFO[4][10] - GyroSavedCaliData.GyroYOffset;//=MPU6050_FIFO[4][10];
		*gz = MPU6050_FIFO[5][10] - GyroSavedCaliData.GyroZOffset;//=MPU6050_FIFO[5][10];
	}
}

void MPU6050_getlastMotion6(int16_t* ax, int16_t* ay, 
		int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz)
{
	*ax = MPU6050_FIFO[0][10];
	*ay = MPU6050_FIFO[1][10];
	*az = MPU6050_FIFO[2][10];
	*gx = MPU6050_FIFO[3][10]-GyroSavedCaliData.GyroXOffset;
	*gy = MPU6050_FIFO[4][10]-GyroSavedCaliData.GyroYOffset;
	*gz = MPU6050_FIFO[5][10]-GyroSavedCaliData.GyroZOffset;
}

/**************************实现函数********************************************
*函数原型:	   void IMU_getValues(volatile float * values)
*功　　能:	 读取加速度 陀螺仪 磁力计 的当前值  
输入参数： 将结果存放的数组首地址
加速度值：原始数据，-8192-+8192
角速度值：deg/s
磁力计值：原始数据
输出参数：没有
*******************************************************************************/
void IMU_getValues(volatile float * values) {  
		int16_t accgyroval[6];
		int i;
	//读取加速度和陀螺仪的当前ADC
	MPU6050_getMotion6(&accgyroval[0], &accgyroval[1], &accgyroval[2], &accgyroval[3], &accgyroval[4], &accgyroval[5]);
	MPU6050_Raw_Data.Accel_X = accgyroval[0];
	MPU6050_Raw_Data.Accel_Y = accgyroval[1];
	MPU6050_Raw_Data.Accel_Z = accgyroval[2];
	MPU6050_Raw_Data.Gyro_X = accgyroval[3];
	MPU6050_Raw_Data.Gyro_Y = accgyroval[4];
	MPU6050_Raw_Data.Gyro_Z = accgyroval[5];
	
	
    for(i = 0; i<6; i++) {
      if(i < 3) {
        values[i] = (float) accgyroval[i];
      }
      else {
        values[i] = ((float) accgyroval[i]) / 32.8f; //转成度每秒
		//这里已经将量程改成了 1000度每秒  32.8 对应 1度每秒
      }
    }
	values[3] -= Gyro_x_err;
	values[4] -= Gyro_y_err;
	values[5] -= Gyro_z_err;
}

/**************************实现函数********************************************
*函数原型:	   void IMU_AHRSupdate
*功　　能:	 更新AHRS 更新四元数 //互补滤波
输入参数： 当前的测量值。
输出参数：没有
*******************************************************************************/
//float Kp=0.0f;   // proportional gain governs rate of convergence to accelerometer/magnetometer
////float Ki=0.0084f;   // integral gain governs rate of convergence of gyroscope biases
//float Ki=0.0f;   // integral gain governs rate of convergence of gyroscope biases


//int count_init = 0;
//float z_err_p = 0;
//void IMU_AHRSupdate(void) {
//    float norm;
//	float vx, vy, vz;
//    float ex, ey, ez;
//    float tempq0,tempq1,tempq2,tempq3;

//    float q0q0 = q0*q0;
//    float q0q1 = q0*q1;
//    float q0q2 = q0*q2;
//    float q0q3 = q0*q3;
//    float q1q1 = q1*q1;
//    float q1q2 = q1*q2;
//    float q1q3 = q1*q3;
//    float q2q2 = q2*q2;   
//    float q2q3 = q2*q3;
//    float q3q3 = q3*q3;   

//	
//	
//    gx = mygetqval[3] * M_PI/180;
//    gy = mygetqval[4] * M_PI/180;
//    gz = mygetqval[5] * M_PI/180;
//    ax = mygetqval[0] ;
//    ay = mygetqval[1] ;
//    az = mygetqval[2] ;

////	halfT =  0.0005005;
//	halfT =  0.00044f;
//	
////	now = TIM2->CNT;  //读取时间 单位是us   
////	if(now<lastUpdate)
////	{
////		halfT =  (double)(now + (0xffffffff - lastUpdate));   //  uint 0.5s
////	}
////	else	
////	{
////		
////		halfT = (double)(now - lastUpdate);
////	}
////	lastUpdate = now;	//更新时间							//计算采样周期   除2000000.0

//    //快速求平方根算法
//    norm = invSqrt(ax*ax + ay*ay + az*az);       
//    ax = ax * norm;
//    ay = ay * norm;
//    az = az * norm;
//    //把加计的三维向量转成单位向量。
//    vx = 2.0f*(q1q3 - q0q2);
//    vy = 2.0f*(q0q1 + q2q3);
//	vz = q0q0 - q1q1 - q2q2 + q3q3;
//    // error is sum of cross product between reference direction of fields and direction measured by sensors
//    ex = (ay*vz - az*vy);
//    ey = (az*vx - ax*vz);
//    ez = (ax*vy - ay*vx);
//	
//    if(ex != 0.0f && ey != 0.0f && ez != 0.0f)
//    {    	
////		//加入零位修正 以2000ms后稳定的数据作为偏差值使车起始方向为当前方向
//		if(count_init < 2000)
//		{
//			count_init++;
//			adjust.deviation_last_ez = ez;
//		}
//		else
//		{
//			ez -= adjust.deviation_last_ez;
//			exInt = exInt + ex * Ki * halfT;
//			eyInt = eyInt + ey * Ki * halfT;
//			ezInt = ezInt + ez * Ki * halfT;
//			// 用叉积误差来做PI修正陀螺零偏
//			gx = gx + Kp*ex + exInt;
//			gy = gy + Kp*ey + eyInt;
//			gz = gz + Kp*ez + ezInt;
//		}
//    }
//    // 四元数微分方程
//    tempq0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;
//    tempq1 = q1 + (q0*gx + q2*gz - q3*gy)*halfT;
//    tempq2 = q2 + (q0*gy - q1*gz + q3*gx)*halfT;
//    tempq3 = q3 + (q0*gz + q1*gy - q2*gx)*halfT;  

//    // 四元数规范化
//    norm = invSqrt(tempq0*tempq0 + tempq1*tempq1 + tempq2*tempq2 + tempq3*tempq3);
//    q0 = tempq0 * norm;
//    q1 = tempq1 * norm;
//    q2 = tempq2 * norm;
//    q3 = tempq3 * norm;

//}


/**************************实现函数********************************************
*函数原型:	   void IMU_getQ(float * q)
*功　　能:	 更新四元数 返回当前的四元数组值
输入参数： 将要存放四元数的数组首地址
输出参数：没有
*******************************************************************************/

//void IMU_getQ(volatile float * q) {

//    IMU_getValues(mygetqval);	 //获取原始数据,加速度计和磁力计是原始值，陀螺仪转换成了deg/s
//    IMU_AHRSupdate();
//    q[0] = q0; //返回当前值
//    q[1] = q1;
//    q[2] = q2;
//    q[3] = q3;
//}

/**************************实现函数********************************************
*函数原型:	   void IMU_getYawPitchRoll(float * angles)
*功　　能:	 更新四元数 返回当前解算后的姿态数据
输入参数： 将要存放姿态角的数组首地址
输出参数：没有
*******************************************************************************/
static int yaw_count = 0;
float yaw_angle_last = 0, yaw_angle_new = 0;
//void IMU_getYawPitchRoll(volatile float * angles) 
//{
//    IMU_getQ(q); //更新全局四元数
//    //四元数转换成欧拉角，经过三角函数计算即可
//	//Yaw
////  angles[0] = -atan2(2 * q[1] * q[2] + 2 * q[0] * q[3], -2 * q[2]*q[2] - 2 * q[3] * q[3] + 1)* 180/M_PI; // yaw        -pi----pi
//	Yaw_angle_sum_gz += ((mygetqval[5])/810);
//	angles[0] = Yaw_angle_sum_gz + 90;												//Yaw
//	//Pitch
//	angles[1] = -asin(-2 * q[1] * q[3] + 2 * q[0] * q[2])* 180/M_PI; // Pitch    -pi/2    --- pi/2 
//	//Roll
//    angles[2] = atan2(2 * q[2] * q[3] + 2 * q[0] * q[1], -2 * q[1] * q[1] - 2 * q[2] * q[2] + 1)* 180/M_PI; // roll       -pi-----pi  
//}

void IMU_getYawPitchRoll(volatile float * angles) 
{
    IMU_getValues(mygetqval);	 //获取原始数据,加速度计和磁力计是原始值，陀螺仪转换成了deg/s
	//Yaw
	Yaw_angle_sum_gz += mygetqval[5] / 810.0f;
	yaw_angle_last = yaw_angle_new;
	yaw_angle_new = Yaw_angle_sum_gz + 90;
	if(yaw_temp-last_yaw_temp>=150)
		yaw_count--;
	else if(yaw_temp-last_yaw_temp<=-150)
		yaw_count++;
	angles[0] = yaw_angle_new + yaw_count*360;	
	//Pitch
	Pitch_angle_sum_gx += mygetqval[3] / 1000.0f;
	angles[2] = Pitch_angle_sum_gx + 90.0f;
}

void GetTheFinal()
{
	MPU6050_Real_Data.Gyro_X = mygetqval[3];
	MPU6050_Real_Data.Gyro_Y = -mygetqval[4];
	MPU6050_Real_Data.Gyro_Z = mygetqval[5];
	yaw_angle = angle[0];
	pitch_angle = angle[2];
	
	real_angle.yaw = yaw_angle;
	real_angle.pitch = pitch_angle;
	real_angle.gx = MPU6050_Real_Data.Gyro_X/10.0f;
	real_angle.gz = MPU6050_Real_Data.Gyro_Z/10.0f;
}

void EXTI2_IRQHandler(void)         //中断频率1KHz
{   
    if(EXTI_GetITStatus(EXTI_Line2) != RESET)
    {    
        EXTI_ClearFlag(EXTI_Line2);          
        EXTI_ClearITPendingBit(EXTI_Line2);
        //读取原始数据
        MPU6050_is_DRY = 1;   //mpu6050中断标志
        GetTheFinal();//读取姿态数据,数据已经处理成连续方式	
    }
}
